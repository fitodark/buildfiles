CLIENT_AUTH0=BC5a3xSMdS06O8EeJkCp2mZRfRvKxAAz DOMAIN_AUTH0=paridin.auth0.com NODE_ENV=production yarn run dev &
