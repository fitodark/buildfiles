var webpack = require('webpack')
var DashboardPlugin = require('webpack-dashboard/plugin')
var ProvidePlugin = require('webpack/lib/ProvidePlugin');
var CommonsChunkPlugin = require("webpack/lib/optimize/CommonsChunkPlugin")
var path = require('path')
var loaders = require('./webpack.loaders')
var HtmlWebpackPlugin = require('html-webpack-plugin')
var CopyWebpackPlugin = require('copy-webpack-plugin');
var pkg = require('./package.json')
var BUILD_DIR = path.resolve(__dirname, 'dist')
var APP_DIR = path.resolve(__dirname, 'src')

/*
Issue with routes like this <Route path='/foo/:id' />, The problem is you loss the page after refreshing it

that's why because it attemps to relative path:
`http://localhost:8915/foo/app.js 404 (Not Found)` insted of `http://localhost:8915/app.js`

answer by @vcarl
if you are using html-webpack-plugin set publicPath: '/' under output: { } in webpack.config.js
html-webpack-plugin uses it to locate your assets, with no public path it tries to use relative paths
or rather, doesn't do anything to the filenames, so it has src="app.js" which is a relative path
that's fine for single-level routes like /home or /positions but once you get a second / in there
it starts trying to do /positions/app.js which doesn't exist.
*/

/**
 * excludeOfVendors Is usable to exclude a vendor.
 *
 * What is a vendor?, a vendor is a third party project used in your code base
 *
 * Why this functions?,
 *
 * That's because in the project some time we want to chunk our js filenames
 * app and vendors
 *
 * the easy way to import those vendors in our webpack is including the package.json
 * and read the key of our dependencies node, and some vendors causes problems
 *
 * ``` ERROR in multi vendors
   Module not found: Error: Cannot resolve module 'react-icons' in /foo/project
   @ multi vendors
   ```
 *
 * Example in webpack.config.js file
 *
 *
 * var CommonsChunkPlugin = require("webpack/lib/optimize/CommonsChunkPlugin")
 * var pkg = require('./package.json')
 * var _toExclude = ['babel-core', 'webpack', 'react-icons']
 * entry = {
 * ...
 * vendors: Object.keys(pkg.dependencies)
                .filter(name => excludeOfVendors(name, _toExclude))
 * },
 * plugins: [
 *  new CommonsChunkPlugin('vendors', 'vendors.min.js'),
 * ]
 *
 * @param  {String} name The vendor name to exclude
 * @param  {Array}  vendors The list of vendors
 * @return {Array}       Array with vendors to chunk our file
 */
function excludeOfVendors(name, vendors) {
  return vendors.indexOf(name) === -1
}
var _toExclude = ['babel-core', 'webpack']

var config = {
  context: __dirname,
  entry: {
    app: ['react-hot-loader/patch', APP_DIR + '/index.js'],
    vendors: Object.keys(pkg.dependencies)
                   .filter(name => excludeOfVendors(name, _toExclude))
  },
  resolve: { alias: {} },
  plugins: [
    new DashboardPlugin({}),
		new webpack.NoErrorsPlugin(),
		new webpack.HotModuleReplacementPlugin(),
    // new webpack.optimize.UglifyJsPlugin({
    //     compress: {
    //         warnings: false
    //     }
    // }), // only uncomment when try to compile it makes slow the development
    // new CopyWebpackPlugin([{ from: APP_DIR + '/assets/sass', to: 'assets' }]),
    new CommonsChunkPlugin('vendors', 'vendors.min.js'),
		new HtmlWebpackPlugin({
      title: "Admin Xideral Website",
      inject: false,
			template: APP_DIR + '/app.html',
		}),
    new webpack.DefinePlugin({
    'process.env': {
      'NODE_ENV': JSON.stringify('development')
      },
    })
	],

  output: {
    path: BUILD_DIR,
    filename: '[name].min.js',
    publicPath: '/' // With html-webpack-plugin is necesary to make absolute paths
  },

  devServer: {
    contentBase: "./app",
    // do not print bundle build stats
    noInfo: true,
    // enable HMR
    hot: true,
    // embed the webpack-dev-server runtime into the bundle
    inline: true,
    // serve index.html in place of 404 responses to allow HTML5 history
    historyApiFallback: true,
    port: 8916,
    host: '0.0.0.0', // local
    disableHostCheck: true
  },

  module: {
    noParse: [],
    loaders
  }
};

module.exports = config;
