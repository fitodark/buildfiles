// routes.js
import React from 'react'
import { Route, IndexRoute } from 'react-router'

// local components
import App from './app/app'
import Dashboard from './dashboard/dashboard'
import Home from './shared-pages/home'
import CandidatePage from './candidates/page'
import CandidateList from './candidates/list'
import CandidateDetail from './candidates/detail'
import CandidateNew from './candidates/add'

import DeptoPage from './departments/depts'

import PositionPage from './positions/page'
import PositionList from './positions/list'
import PositionDetail from './positions/detail'
import PositionNew from './positions/add'

import PostPage from './news/page'
import PostList from './news/list'
import PostDetail from './news/detail'
import PostEdit from './news/edit'
import PostNew from './news/add'

import NotFound from './shared-pages/not-found'
import Restricted from './auth/restricted'

export default (
  <Route path="/" component={App}>
    <IndexRoute component={Home} />
    <Route component={Restricted}>
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/candidates" component={CandidatePage}>
        <IndexRoute component={CandidateList} />
        <Route path="/candidates/new" component={CandidateNew} />
        <Route path="/candidates/detail/:id" component={CandidateDetail} />
      </Route>
      
      <Route path="/departments" component={DeptoPage} />

      <Route path="/news" component={PostPage}>
        <IndexRoute component={PostList} />
        <Route path="/news/new" component={PostNew} />
        <Route path="/news/detail/:id" component={PostDetail} />
        <Route path="/news/edit/:id" component={PostEdit} />
      </Route>

      <Route path="/positions" component={PositionPage}>
        <IndexRoute component={PositionList} />
        <Route path="/positions/new" component={PositionNew} />
        <Route path="/positions/detail/:id" component={PositionDetail} />
      </Route>
    </Route>
    <Route path="*" component={NotFound} />
  </Route>
)

