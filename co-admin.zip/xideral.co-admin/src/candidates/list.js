import React, { PropTypes } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import functional from 'react-functional'
import {
    Card,
    HeadingLink
} from 'rebass'
import _ from 'lodash'

import { candidatesFetch } from './reducer'
import {
    getSortedCandidates,
    getCandidatesError,
    getCandidatesIsLoading
} from './selectors'
import { selectors as authSelectors } from '../auth'
import Loader from '../shared-pages/loader'
import {
    renderCardImage,
    renderDate,
    renderUntilFirstDot
} from '../libs/utils'

import { renderLinkedInCandidate, renderCandidate } from './detail'

const CandidatesList = ({ isLoading, candidates, error }) => (
    isLoading ? <Loader /> :
    <section style={{ display: 'flex', flexFlow: 'row wrap' }}>
    <div className = "error" > { error ? error : null } </div> 
    {console.log('my candidates', candidates)}
    {_.sortBy(candidates, ['createdAt', 'name'])
        .map(obj => (
            <Card key={obj._id} m={3} style={{width: '280px', height: '350px'}}>
                <HeadingLink level={3} 
                    href={`/candidates/detail/${obj._id}`} rel="noopener noreferrer" >{ obj.name }</HeadingLink> 
                {obj.linkedinId ? 
                    renderLinkedInCandidate(obj, JSON.parse(JSON.parse(obj.raw))) : 
                    renderCandidate(obj)}
            </Card>
        ))
    }
    </section>
)

CandidatesList.propTypes = {
    candidates: PropTypes.array.isRequired,
    isLoading: PropTypes.bool.isRequired,
    error: PropTypes.object
}

CandidatesList.componentDidMount = ({
    idToken,
    actions
}) => actions.candidatesFetch(idToken)

const mapStateToProps = state => ({
    idToken: authSelectors.getIdToken(state),
    candidates: getSortedCandidates(state),
    isLoading: getCandidatesIsLoading(state),
    error: getCandidatesError(state)
})

const mapDispatchToProps = dispatch => ({
    actions: bindActionCreators({
        candidatesFetch
    }, dispatch)
})

export default connect(mapStateToProps, mapDispatchToProps)(functional(CandidatesList))
