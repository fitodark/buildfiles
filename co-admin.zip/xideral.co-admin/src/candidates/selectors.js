import _ from 'lodash'
import { createSelector } from 'reselect'

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// SELECTORS FOR CANDIDATES
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
const getCandidates = state => state.candidates.candidateList.candidates

export const getCandidatesError = state => state.candidates.candidateList.error

export const getCandidatesIsLoading = state => state.candidates.candidateList.loading

export const getSortedCandidates = createSelector(
    [getCandidates],
    candidates => _.sortBy(candidates, ['name'])
)

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// SELECTORS FOR CANDIDATE
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
export const getCandidate = state => state.candidates.activeCandidate.candidate 

export const getCandidateEditable = state => state.candidates.activeCandidate.editable

export const getCandidateError = state => state.candidates.activeCandidate.error

export const getCandidateIsLoading = state => state.candidates.activeCandidate.loading

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// SELECTORS FOR ADD A NEW CANDIDATE
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 

export const getNewCandidate = state => state.candidates.newCandidate.candidate 

export const getNewCandidateError = state => state.candidates.newCandidate.error

export const getNewCandidateIsLoading = state => state.candidates.newCandidate.loading