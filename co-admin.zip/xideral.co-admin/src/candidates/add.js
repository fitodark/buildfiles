import _ from 'lodash'
import React, { PropTypes } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import functional from 'react-functional'

// local libraries
import { CandidateAddForm } from './forms'
import Loader from '../shared-pages/loader'
import { candidateReset, candidateDeletedReset } from './reducer'
import { selectors as authSelectors } from '../auth'
import { getNewCandidate, getNewCandidateError, getNewCandidateIsLoading } from './selectors'

const CandidateNew = ({isLoading, error}) => (
  isLoading ? <Loader /> :
  <section>
    {error ? <div className="error">{error}</div> : null}
    <CandidateAddForm />
  </section>
)

CandidateNew.propTypes = {
  isLoading: PropTypes.bool.isRequired,
  error: PropTypes.object
}

CandidateNew.componentWillUnmount = ({actions}) => {
  actions.candidateReset()
  actions.candidateDeletedReset()
}

const mapStateToProps = state => ({
  idToken: authSelectors.getIdToken(state),
  candidate: getNewCandidate(state),
  isLoading: getNewCandidateIsLoading(state),
  error: getNewCandidateError(state)
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators ({
    candidateReset,
    candidateDeletedReset
  }, dispatch)
})


export default connect(mapStateToProps, mapDispatchToProps)(functional(CandidateNew))