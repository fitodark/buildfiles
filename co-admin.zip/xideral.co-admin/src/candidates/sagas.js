import 'isomorphic-fetch'
import { call, put, take } from 'redux-saga/effects'

import { 
    CANDIDATES_FETCH,
    CANDIDATE_FETCH,
    CANDIDATE_UPDATE,
    CANDIDATE_NEW,
    candidatesSuccess,
    candidatesFailure,
    candidateSuccess,
    candidateFailure,
    candidateUpdateSuccess,
    candidateUpdateFailure,
    candidateNewSuccess,
    candidateNewFailure
} from './reducer'

import { fetchCandidates, fetchCandidate, updateCandidate, saveCandidate, handleApiError } from '../api'

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// SAGAS FOR CANDIDATES
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
export function* fetchCandidatesSaga(idToken) {
    try {
        const { candidates } = yield call(fetchCandidates, idToken)
        
        yield put(candidatesSuccess(candidates))
    } catch (error) {
        yield call(handleApiError, error, candidatesFailure)
    }
}

export function* fetchCandidateSaga(idToken, id) {
    try {
        const { candidate } = yield call(fetchCandidate, idToken, id)
        yield put(candidateSuccess(candidate))
    } catch (error) {
        yield call(handleApiError, error, candidateFailure)
    }
}

export function* fetchCandidateUpdateSaga(idToken, id, update) {
    try {
        const { candidate } = yield call(updateCandidate, idToken, id, update)
        yield put(candidateUpdateSuccess(candidate))
    } catch (error) {
        yield call(handleApiError, error, candidateUpdateFailure)
    }
}

export function* saveCandidateSaga(idToken, newCandidate) {
    try {
        const { candidate } = yield call(saveCandidate, idToken, newCandidate)
        yield put(candidateNewSuccess(candidate))
    } catch (error) {
        yield call(handleApiError, error, candidateNewFailure)
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// DAEMONS FOR CANDIDATES
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
export function* watchCandidatesRequest() {
    while(true) {
        const { idToken } = yield take(CANDIDATES_FETCH)
        yield call(fetchCandidatesSaga, idToken)
    }
}

export function* watchCandidateRequest() {
    while(true) {
        const { idToken, id } = yield take(CANDIDATE_FETCH)
        yield call(fetchCandidateSaga, idToken, id)
    }
}

export function* watchCandidateUpdate() {
    while(true) {
        const { idToken, id, update } = yield take(CANDIDATE_UPDATE)
        yield call(fetchCandidateUpdateSaga, idToken, id, update)
    }
}

export function* watchCandidateSave() {
    while(true) {
        const { idToken, newCandidate } = yield take(CANDIDATE_NEW)
        yield call(saveCandidateSaga, idToken, newCandidate)
    }
}