import _ from 'lodash'
import React, { PropTypes } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import functional from 'react-functional'
import { Text } from 'rebass'

// local libraries
import { CandidateUpdateForm } from './forms'
import Loader from '../shared-pages/loader'
import { candidateFetch, candidateReset, candidateDeletedReset, candidateEditable } from './reducer'
import { selectors as authSelectors } from '../auth'
import { getCandidate, getCandidateEditable, getCandidateError, getCandidateIsLoading } from './selectors'

export const renderLinkedInCandidate = (data, raw) => (<div className="details">
    <div style = {{ textAlign: 'center', margin: '4px auto' }}>
        <img className="avatar" src={ raw.pictureUrl} alt={ raw.formattedName} /> 
    </div>
    <Text>Linkedin: <a href={ raw.publicProfileUrl } target="_blank"> Ver perfil. </a></Text >
    <Text>Linkedin Email: { data.email } </Text>
</div>)

export const renderCandidate = data => (<div className="details">
    <Text>CV: <a href={ data.document_url } target="_blank"> Ver / Descargar. </a></Text >
    <Text>Email: { data.email }</Text> 
    <Text>Teléfono: { data.phone }</Text>
    <Text>Habilidades: { data.skills }</Text> 
</div>)


const CandidateDetail = ({isLoading, candidate, editable, error, actions}) => (
  isLoading ? <Loader /> :
  <section>
    <h3>{candidate.name}</h3>
    {candidate.linkedinId ? renderLinkedInCandidate(candidate, JSON.parse(JSON.parse(obj.raw))) : 
                    renderCandidate(candidate)}
    
    <button className={"btn btn-yellow"} onClick={() => actions.candidateEditable(candidate)}>Editar</button>
    {editable ? <CandidateUpdateForm candidate={candidate} /> : null}
  </section>
)

CandidateDetail.propTypes = {
  candidate: PropTypes.object.isRequired,
  isLoading: PropTypes.bool.isRequired,
  editable: PropTypes.bool.isRequired,
  error: PropTypes.object
}

CandidateDetail.componentDidMount = ({idToken, id, actions}) => {
  return actions.candidateFetch(idToken, id)
}
CandidateDetail.componentWillUnmount = ({actions}) => {
  actions.candidateReset()
  actions.candidateDeletedReset()
}

const mapStateToProps = (state, ownProps) => ({
  idToken: authSelectors.getIdToken(state),
  id: ownProps.params.id,
  candidate: getCandidate(state),
  editable: getCandidateEditable(state),
  isLoading: getCandidateIsLoading(state),
  error: getCandidateError(state)
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators ({
    candidateFetch,
    candidateEditable,
    candidateReset,
    candidateDeletedReset
  }, dispatch)
})


export default connect(mapStateToProps, mapDispatchToProps)(functional(CandidateDetail))
