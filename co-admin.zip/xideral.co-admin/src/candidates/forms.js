import 'isomorphic-fetch'
import _ from 'lodash'
import React from 'react'
import { Field, Form, reduxForm } from 'redux-form'
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import uuid from 'uuid'
import Dropzone from 'react-dropzone'
import { browserHistory } from 'react-router'

// local components
import { selectors as authSelectors } from '../auth'
import { candidateUpdate, candidateNew, candidateCancelEdition } from './reducer'
import { getCandidate } from './selectors'
import {API_URI} from '../api'

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FORM COMMONS
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const FIELDS = {
  document_url: {
    node: 'input',
    type: 'file',
    label: 'Anexa el CV.'
  },
  name: {
    node: 'input',
    type: 'text',
    label: 'Nombre.'
  },
  email: {
    node: 'input',
    type: 'email',
    label: 'Correo electrónico.'
  },
  phone: {
    node: 'input',
    type: 'text',
    label: 'Teléfono (10 dígitos).'
  },
  skills: {
    node: 'textarea',
    type: 'text',
    label: 'Habilidades (separar con coma).'
  }
}

const renderInput = (fieldConfig, field) => (
  <div key={`field_${field}`} className={field.touched && field.invalid ? 'danger' : ''}>
    <label htmlFor={field}>{fieldConfig.label}</label><br />

    {fieldConfig.type !== 'file' ?
      <Field component={fieldConfig.node} type={fieldConfig.type} name={field} className="form-control" /> :
      <Field name={field} component={renderDropzone} />}

    <div className="text-help">
      {field.touched ? field.error : ''}
    </div>
  </div>
)

async function uploadToS3(files) {
  const file = files[0]
  const response = await fetch(`${API_URI}/getSignedUrl?folder=candidates&filename=${file.name}&filetype=${file.type}`, {
    method: 'GET'
  })
  const signedUrl = await response.json().then(json => json.url)
  const s3File = await fetch(signedUrl, {
    method: 'PUT',
    headers: {
      'Content-Type': file.type
    },
    body: file
  })
  file['value'] = s3File.url.split("?")[0]
  return [file]
}

function validate(values) {
  const errors = {}
  _.each(FIELDS, (type, field) => {
    if (!values[field]) {
      errors[field] = `Debe llenar el campo ${field}`
    }
  })
  return errors
}

const renderDropzone = (field) => {
  const files = field.input.value;
  return (
    <div>
      <Dropzone
        name={field.name}
        maxSize={2.097e6}
        accept="application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        multiple={false}
        onDrop={( filesToUpload, e ) => uploadToS3(filesToUpload).then(files => field.input.onChange(files))}
        className={"dropzone"}
        >
        <div>Arrastra el CV en formato PDF, Doc(x).</div>
      </Dropzone>
      <div></div>
      {field.meta.touched &&
        field.meta.error &&
        <span className="error">{field.meta.error}</span>}
      {files && Array.isArray(files) && (
        <ul>
          { files.map((file, i) => <li key={i}>{file.name}</li>) }
        </ul>
      )}
    </div>
  );
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FORM FOR CANDIDATE UPDATE
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

const updateCandidate = (values, idToken, id, dispatch) => {
  if (Array.isArray(values['document_url'])) {
    values['document_url'] = values['document_url'][0].value // removing the file context to save only the url
  }
  dispatch(idToken, id, values)
  alert('Se actualizó correctamente.')
}

const CandidateUpdateForm = ({idToken, handleSubmit, candidate, actions}) => (
<section className="form-pane">
  <nav style={{ display: 'flex', justifyContent: 'flex-end'}}>
    <span style={{ cursor: 'pointer', fontSize: '18px', fontWeight: 'bolder'}}
          onClick={() => actions.candidateCancelEdition(candidate)}>X</span>
  </nav>
  <Form onSubmit={handleSubmit((data) => updateCandidate(data, idToken, candidate._id, actions.candidateUpdate))} className={"form-column"}>
    {_.map(FIELDS, (fieldConfig, field) => (
      renderInput(fieldConfig, field)
    ))}
    <button type="submit" className={`btn btn-yellow`}>Guardar</button>
  </Form>
</section>)

const mapStateToProps = state => ({
  idToken: authSelectors.getIdToken(state),
  initialValues: getCandidate(state)
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators({
    candidateCancelEdition,
    candidateUpdate,
  }, dispatch)
})

const UpdateForm = connect(mapStateToProps, mapDispatchToProps)(reduxForm({
  form: 'CandidateUpdateForm',
  fields: _.keys(FIELDS),
  validate
})(CandidateUpdateForm))

export { UpdateForm as CandidateUpdateForm }



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FORM FOR CANDIDATE NEW
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


const addCandidate = (values, idToken, dispatch) => {
  if (Array.isArray(values['document_url'])) {
    values['document_url'] = values['document_url'][0].value // removing the file context to save only the url
  }
  dispatch(idToken, values)
  alert('Se creó satisfactoriamente.')
  browserHistory.push('/candidates')
}

const mapStateToPropsAdd = state => ({
  idToken: authSelectors.getIdToken(state)
})

const mapDispatchToPropsAdd = dispatch => ({
  actions: bindActionCreators({
    candidateCancelEdition,
    candidateNew,
  }, dispatch)
})

const CandidateAddForm = ({idToken, handleSubmit, actions}) => (
<section className="form-pane">
  <nav style={{ display: 'flex', justifyContent: 'flex-end'}}>
    <span style={{ cursor: 'pointer', fontSize: '18px', fontWeight: 'bolder'}}
          onClick={() => browserHistory.push('/candidates')}>X</span>
  </nav>
  <Form onSubmit={handleSubmit((data) => addCandidate(data, idToken, actions.candidateNew))} className={"form-column"}>
    {_.map(FIELDS, (fieldConfig, field) => (
      renderInput(fieldConfig, field)
    ))}
    <button type="submit" className={`btn btn-yellow`}>Guardar</button>
  </Form>
</section>)

const AddForm = connect(mapStateToPropsAdd, mapDispatchToPropsAdd)(reduxForm({
  form: 'CandidateAddForm',
  fields: _.keys(FIELDS),
  validate
})(CandidateAddForm))

export { AddForm as CandidateAddForm }
