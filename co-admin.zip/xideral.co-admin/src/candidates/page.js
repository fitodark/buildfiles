import React, { PropTypes } from 'react'
import { Link } from 'react-router'

const CandidatePage = ({children}) => (
    <section>
        <header className={"actions_page"}>
            <Link onlyActiveOnIndex activeClassName="active" to='/candidates'>Listado</Link>
            <Link onlyActiveOnIndex activeClassName="active" to='/candidates/new'>Nuevo</Link>
        </header>
        <div>{children}</div>
    </section>
)

CandidatePage.propTypes = {
    children: PropTypes.node.isRequired
}

export default CandidatePage