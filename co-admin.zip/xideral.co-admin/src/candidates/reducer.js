// List
export const CANDIDATES_FETCH = 'CANDIDATES_FETCH'
export const CANDIDATES_SUCCESS = 'CANDIDATES_SUCCESS'
export const CANDIDATES_FAILURE = 'CANDIDATES_FAILURE'
export const CANDIDATES_RESET = 'CANDIDATES_RESET'

export const CANDIDATE_FETCH = 'CANDIDATE_FETCH'
export const CANDIDATE_SUCCESS = 'CANDIDATE_SUCCESS'
export const CANDIDATE_FAILURE = 'CANDIDATE_FAILURE'
export const CANDIDATE_EDITABLE = 'CANDIDATE_EDITABLE'
export const CANDIDATE_NON_EDITABLE = 'CANDIDATE_NON_EDITABLE'
export const CANDIDATE_RESET = 'CANDIDATE_RESET'

export const CANDIDATE_UPDATE = 'CANDIDATE_UPDATE'
export const CANDIDATE_UPDATE_SUCCESS = 'CANDIDATE_UPDATE_SUCCESS'
export const CANDIDATE_UPDATE_FAILURE = 'CANDIDATE_UPDATE_FAILURE'

export const CANDIDATE_DELETE_RESET = 'CANDIDATE_DELETE_RESET'

export const CANDIDATE_NEW = 'CANDIDATE_NEW'
export const CANDIDATE_NEW_SUCCESS = 'CANDIDATE_NEW_SUCCESS'
export const CANDIDATE_NEW_FAILURE = 'CANDIDATE_NEW_FAILURE'

export const initialState = {
    candidateList: {
        candidates: [],
        loading: false,
        error: null,
    },
    newCandidate: {
        candidate: {},
        loading: false,
        error: null,
    },
    activeCandidate: {
        candidate: {},
        loading: false,
        editable: false,
        isUpdating: false,
        error: null,
    },
    deleteCandidate: {
        candidate: {},
        loading: false,
        error: null,
    }
}

export default function reducer(state = initialState, action) {
    switch (action.type) {
        // candidates
        case CANDIDATES_FETCH:
            return { ...state, 
                    candidateList: 
                        {candidates: [], error: null, loading: true}}
        case CANDIDATES_SUCCESS:
            return { ...state, 
                    candidateList: 
                        {candidates: action.candidates, error: null, loading: false}}
        case CANDIDATES_FAILURE:
            return { ...state, 
                    candidateList: 
                        {candidates: [], error: action.error, loading: false}}
        case CANDIDATES_RESET:
            return { ...state, 
                    candidateList: 
                        {candidates: [], error: null, loading: false}}
        // end candidates
        // candidate
        case CANDIDATE_FETCH:
            return { ...state, activeCandidate: {...state.activeCandidate, loading: true}}
        case CANDIDATE_SUCCESS:
            return { ...state, activeCandidate: {candidate: action.candidate, editable: false, error: null, isUpdating: false, loading: false}}
        case CANDIDATE_EDITABLE:
            return { ...state, activeCandidate: {candidate: action.candidate, editable: true, error: null, isUpdating: false, loading: false}}
        case CANDIDATE_NON_EDITABLE:
            return { ...state, activeCandidate: {candidate: action.candidate, editable: false, error: null, isUpdating: false, loading: false}}
        case CANDIDATE_FAILURE:
            return { ...state, activeCandidate: {candidate: {}, error: action.error, editable: false, isUpdating: false, loading: false}}
        case CANDIDATE_RESET:
            return { ...state, activeCandidate: {candidate: {}, error: null, editable: false, isUpdating: false, loading: false}}
        case CANDIDATE_UPDATE:
            return { ...state, activeCandidate: {candidate: {}, error: null, editable: true, isUpdating: true, loading: false}}
        case CANDIDATE_UPDATE_SUCCESS:
            return { ...state, activeCandidate: {candidate: action.candidate, error: null, editable: true, isUpdating: false, loading: false}}
        case CANDIDATE_UPDATE_FAILURE:
            return { ...state, activeCandidate: {candidate: {}, error: action.error, editable: true, isUpdating: false, loading: false}}
        // end candidates
        default:
            return state
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// ACTIONS FOR CANDIDATES
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
export const candidatesFetch = idToken => ({
    type: CANDIDATES_FETCH,
    idToken
})

export const candidatesSuccess = candidates => ({
    type: CANDIDATES_SUCCESS,
    candidates
})

export const candidatesFailure = error => ({
    type: CANDIDATES_FAILURE,
    error
})

export const candidatesReset = () => ({
    type: CANDIDATES_RESET
})

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// ACTIONS FOR CANDIDATE
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
export const candidateFetch = (idToken, id) => ({
    type: CANDIDATE_FETCH,
    idToken,
    id
})

export const candidateSuccess = candidate => ({
    type: CANDIDATE_SUCCESS,
    candidate
})

export const candidateEditable = candidate => ({
    type: CANDIDATE_EDITABLE,
    candidate
})

export const candidateCancelEdition = candidate => ({
    type: CANDIDATE_NON_EDITABLE,
    candidate
})

export const candidateFailure = error => ({
    type: CANDIDATE_FAILURE,
    error
})

export const candidateReset = () => ({
    type: CANDIDATE_RESET
})

export const candidateDeletedReset = () => ({
    type: CANDIDATE_DELETE_RESET
})

export const candidateUpdate = (idToken, id, update) => ({
    type: CANDIDATE_UPDATE,
    idToken,
    id,
    update
})

export const candidateUpdateSuccess = candidate => ({
    type: CANDIDATE_UPDATE_SUCCESS,
    candidate
})

export const candidateUpdateFailure = error => ({
    type: CANDIDATE_UPDATE_FAILURE,
    error
})

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// ACTIONS FOR A NEW CANDIDATE
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
export const candidateNew = (idToken, newCandidate) => ({
    type: CANDIDATE_NEW,
    idToken,
    newCandidate
})

export const candidateNewSuccess = candidate => ({
    type: CANDIDATE_NEW_SUCCESS,
    candidate
})

export const candidateNewFailure = error => ({
    type: CANDIDATE_NEW_FAILURE,
    error
})
