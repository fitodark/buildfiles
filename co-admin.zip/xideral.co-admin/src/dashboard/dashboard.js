import React from 'react'
import functional from 'react-functional'

const Dashboard = (props) => (<div>Dashboard.</div>)

export default functional(Dashboard)