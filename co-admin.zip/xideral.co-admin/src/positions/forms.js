import 'isomorphic-fetch'
import _ from 'lodash'
import React from 'react'
import { Field, Form, FieldArray, reduxForm } from 'redux-form'
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import uuid from 'uuid'
import Dropzone from 'react-dropzone'
import { browserHistory } from 'react-router'

// local components
import { selectors as authSelectors } from '../auth'
import { positionUpdate, positionNew, positionCancelEdition, positionsFetch } from './reducer'
import { getPosition } from './selectors'
import {API_URI} from '../api'

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FORM COMMONS
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const FIELDS = {
  title: {
    node: 'input',
    type: 'text',
    label: 'Título.',
    placeholder: 'Título de la vacante'
  },
  place: {
    node: 'input',
    type: 'text',
    label: 'Lugar.',
    hint: 'Para crear un nuevo lugar solo escribelo, todas las vacantes son organizadas agrupandolas por el lugar.',
    placeholder: 'Ciudad de México, CDMX, Monterrey, Querétaro'
  },
  area: {
    node: 'input',
    type: 'text',
    label: 'Ubicación especifica.',
    hint: 'Este campo representa la ubicación de la plaza ofertada.',
    placeholder: 'Polanco, Xola, Santa Fe, Nuevo León, Querétaro'
  },
  skills: {
    node: 'textarea',
    type: 'text',
    label: 'Habilidades.',
    hint: 'Separar utilizando una coma las habilidades requeridas en la posición'
  },
  detail: {
    node: 'textarea',
    type: 'text',
    label: 'Detalle.',
    hint: 'Ofrece a tus candidatos más detalle de la posición.'
  },
}

const renderCaseComponent = (fieldConfig, field) => {
  switch (fieldConfig.type){
    case 'file':
      return <Field name={field} component={renderDropzone} />
    case 'array-level-1':
      return <FieldArray name={field} component={children =>
          <ul>
            <li>
              <button type="button" onClick={() => push()}>Add</button>
            </li>
            {/*
            {children.map((child, index) =>
              <li key={index}>
                <button type='button'
                        title='remove'
                        onClick={() => children.remove(index)} />
                <div>
                  <Field name={child} component={childProps =>
                    <div>
                      <input type="text" {...childProps}
                              placeholder={`${fieldConfig.label} #${childIndex + 1}`}/>
                      {childProps.touched && childProps.error && <span>{childProps.error}</span>}
                    </div>
                  }/>
                </div>
              </li>

            )}
          */}
          </ul>}
        />
    default:
      return <Field name={field}
                component={fieldConfig.node}
                type={fieldConfig.type}
                placeholder={fieldConfig.placeholder ? fieldConfig.placeholder : ''}/>
  }
}

const renderInput = (fieldConfig, field) => (
  <div key={`field_${field}`} className={field.touched && field.invalid ? 'danger' : ''}>
    {fieldConfig.hint ? <div className='hint'>{fieldConfig.hint}</div> : null}
    <label htmlFor={field}>{fieldConfig.label}</label>
    {renderCaseComponent(fieldConfig, field)}
    <div className="text-help">
      {field.touched ? field.error : ''}
    </div>
  </div>
)

function validate(values) {
  const errors = {}
  _.each(FIELDS, (type, field) => {
    if (!values[field]) {
      errors[field] = `Debe llenar el campo ${field}`
    }
  })
  return errors
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FORM FOR POSITION UPDATE
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

const updatePosition = (values, idToken, id, dispatch) => {
  values['owner'] = JSON.parse(localStorage.getItem('profile')).name
  const foo = dispatch(idToken, id, values)
  alert('Se actualizó correctamente.')
}

const PositionUpdateForm = ({idToken, handleSubmit, position, actions}) => (
<section className="form-pane">
  <nav style={{ display: 'flex', justifyContent: 'flex-end'}}>
    <span style={{ cursor: 'pointer', fontSize: '18px', fontWeight: 'bolder'}}
          onClick={() => actions.positionCancelEdition(position)}>X</span>
  </nav>
  <Form onSubmit={handleSubmit((data) => updatePosition(data, idToken, position.id, actions.positionUpdate))} className={"form-column"}>
    {_.map(FIELDS, (fieldConfig, field) => (
      renderInput(fieldConfig, field)
    ))}
    <button type="submit" className={`btn btn-yellow`}>Guardar</button>
  </Form>
</section>)

const mapStateToProps = state => ({
  idToken: authSelectors.getIdToken(state),
  initialValues: getPosition(state)
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators({
    positionCancelEdition,
    positionUpdate,
  }, dispatch)
})

const UpdateForm = connect(mapStateToProps, mapDispatchToProps)(reduxForm({
  form: 'PositionUpdateForm',
  fields: _.keys(FIELDS),
  validate
})(PositionUpdateForm))

export { UpdateForm as PositionUpdateForm }



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FORM FOR POSITION NEW
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

const addPosition = (values, idToken, dispatch) => {
  values['owner'] = JSON.parse(localStorage.getItem('profile')).name
  const foo = dispatch(idToken, values)

  alert('Se creó satisfactoriamente.')
  browserHistory.push('/positions')
}

const mapStateToPropsAdd = state => ({
  idToken: authSelectors.getIdToken(state)
})

const mapDispatchToPropsAdd = dispatch => ({
  actions: bindActionCreators({
    positionCancelEdition,
    positionNew,
  }, dispatch)
})

const PositionAddForm = ({idToken, handleSubmit, actions}) => (
<section className="form-pane">
  <nav style={{ display: 'flex', justifyContent: 'flex-end'}}>
    <span style={{ cursor: 'pointer', fontSize: '18px', fontWeight: 'bolder'}}
          onClick={() => browserHistory.push('/positions')}>X</span>
  </nav>
  <Form onSubmit={handleSubmit((data) => addPosition(data, idToken, actions.positionNew))} className={"form-column"}>
    {_.map(FIELDS, (fieldConfig, field) => (
      renderInput(fieldConfig, field)
    ))}
    <button type="submit" className={`btn btn-yellow`}>Guardar</button>
  </Form>
</section>)


const AddForm = connect(mapStateToPropsAdd, mapDispatchToPropsAdd)(reduxForm({
  form: 'PositionAddForm',
  fields: _.keys(FIELDS),
  validate
})(PositionAddForm))

export { AddForm as PositionAddForm }
