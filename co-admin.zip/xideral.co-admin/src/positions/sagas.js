import 'isomorphic-fetch'
import { call, put, take } from 'redux-saga/effects'

import { 
    POSITIONS_FETCH,
    POSITION_FETCH,
    POSITION_UPDATE,
    POSITION_NEW,
    positionsSuccess,
    positionsFailure,
    positionSuccess,
    positionFailure,
    positionUpdateSuccess,
    positionUpdateFailure,
    positionNewSuccess,
    positionNewFailure
} from './reducer'

import { fetchPositions, fetchPosition, updatePosition, savePosition, handleApiError } from '../api'

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// SAGAS FOR POSITIONS
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
export function* fetchPositionsSaga(idToken) {
    try {
        const { positions } = yield call(fetchPositions, idToken)
        
        yield put(positionsSuccess(positions))
    } catch (error) {
        yield call(handleApiError, error, positionsFailure)
    }
}

export function* fetchPositionSaga(idToken, id) {
    try {
        console.log('fetchPositionSaga')
        const { position } = yield call(fetchPosition, idToken, id)
        console.log('fetchPositionSaga -> position', position)
        yield put(positionSuccess(position))
    } catch (error) {
        yield call(handleApiError, error, positionFailure)
    }
}

export function* fetchPositionUpdateSaga(idToken, id, update) {
    try {
        const { position } = yield call(updatePosition, idToken, id, update)
        yield put(positionUpdateSuccess(position))
    } catch (error) {
        yield call(handleApiError, error, positionUpdateFailure)
    }
}

export function* savePositionSaga(idToken, newPosition) {
    try {
        const { position } = yield call(savePosition, idToken, newPosition)
        yield put(positionNewSuccess(position))
    } catch (error) {
        yield call(handleApiError, error, positionNewFailure)
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// DAEMONS FOR POSITIONS
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
export function* watchPositionsRequest() {
    while(true) {
        const { idToken } = yield take(POSITIONS_FETCH)
        yield call(fetchPositionsSaga, idToken)
    }
}

export function* watchPositionRequest() {
    while(true) {
        const { idToken, id } = yield take(POSITION_FETCH)
        yield call(fetchPositionSaga, idToken, id)
    }
}

export function* watchPositionUpdate() {
    while(true) {
        const { idToken, id, update } = yield take(POSITION_UPDATE)
        yield call(fetchPositionUpdateSaga, idToken, id, update)
    }
}

export function* watchPositionSave() {
    while(true) {
        const { idToken, newPosition } = yield take(POSITION_NEW)
        yield call(savePositionSaga, idToken, newPosition)
    }
}