// List
export const POSITIONS_FETCH = 'POSITIONS_FETCH'
export const POSITIONS_SUCCESS = 'POSITIONS_SUCCESS'
export const POSITIONS_FAILURE = 'POSITIONS_FAILURE'
export const POSITIONS_RESET = 'POSITIONS_RESET'

export const POSITION_FETCH = 'POSITION_FETCH'
export const POSITION_SUCCESS = 'POSITION_SUCCESS'
export const POSITION_FAILURE = 'POSITION_FAILURE'
export const POSITION_EDITABLE = 'POSITION_EDITABLE'
export const POSITION_NON_EDITABLE = 'POSITION_NON_EDITABLE'
export const POSITION_RESET = 'POSITION_RESET'

export const POSITION_UPDATE = 'POSITION_UPDATE'
export const POSITION_UPDATE_SUCCESS = 'POSITION_UPDATE_SUCCESS'
export const POSITION_UPDATE_FAILURE = 'POSITION_UPDATE_FAILURE'

export const POSITION_DELETE_RESET = 'POSITION_DELETE_RESET'

export const POSITION_NEW = 'POSITION_NEW'
export const POSITION_NEW_SUCCESS = 'POSITION_NEW_SUCCESS'
export const POSITION_NEW_FAILURE = 'POSITION_NEW_FAILURE'

export const initialState = {
    positionList: {
        positions: [],
        loading: false,
        error: null,
    },
    newPosition: {
        position: {},
        loading: false,
        error: null,
    },
    activePosition: {
        position: {},
        loading: false,
        editable: false,
        isUpdating: false,
        error: null,
    },
    deletePosition: {
        position: {},
        loading: false,
        error: null,
    }
}

export default function reducer(state = initialState, action) {
    switch (action.type) {
        // positions
        case POSITIONS_FETCH:
            return { ...state, 
                    positionList: 
                        {positions: [], error: null, loading: true}}
        case POSITIONS_SUCCESS:
            return { ...state, 
                    positionList: 
                        {positions: action.positions, error: null, loading: false}}
        case POSITIONS_FAILURE:
            return { ...state, 
                    positionList: 
                        {positions: [], error: action.error, loading: false}}
        case POSITIONS_RESET:
            return { ...state, 
                    positionList: 
                        {positions: [], error: null, loading: false}}
        // end positions
        // position
        case POSITION_FETCH:
            return { ...state, activePosition: {...state.activePosition, loading: true}}
        case POSITION_SUCCESS:
            return { ...state, activePosition: {position: action.position, editable: false, error: null, isUpdating: false, loading: false}}
        case POSITION_EDITABLE:
            return { ...state, activePosition: {position: action.position, editable: true, error: null, isUpdating: false, loading: false}}
        case POSITION_NON_EDITABLE:
            return { ...state, activePosition: {position: action.position, editable: false, error: null, isUpdating: false, loading: false}}
        case POSITION_FAILURE:
            return { ...state, activePosition: {position: {}, error: action.error, editable: false, isUpdating: false, loading: false}}
        case POSITION_RESET:
            return { ...state, activePosition: {position: {}, error: null, editable: false, isUpdating: false, loading: false}}
        case POSITION_UPDATE:
            return { ...state, activePosition: {position: {}, error: null, editable: true, isUpdating: true, loading: false}}
        case POSITION_UPDATE_SUCCESS:
            return { ...state, activePosition: {position: action.position, error: null, editable: true, isUpdating: false, loading: false}}
        case POSITION_UPDATE_FAILURE:
            return { ...state, activePosition: {position: {}, error: action.error, editable: true, isUpdating: false, loading: false}}
        // end positions
        default:
            return state
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// ACTIONS FOR POSITIONS
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
export const positionsFetch = idToken => ({
    type: POSITIONS_FETCH,
    idToken
})

export const positionsSuccess = positions => ({
    type: POSITIONS_SUCCESS,
    positions
})

export const positionsFailure = error => ({
    type: POSITIONS_FAILURE,
    error
})

export const positionsReset = () => ({
    type: POSITIONS_RESET
})

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// ACTIONS FOR POSITION
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
export const positionFetch = (idToken, id) => ({
    type: POSITION_FETCH,
    idToken,
    id
})

export const positionSuccess = position => ({
    type: POSITION_SUCCESS,
    position
})

export const positionEditable = position => ({
    type: POSITION_EDITABLE,
    position
})

export const positionCancelEdition = position => ({
    type: POSITION_NON_EDITABLE,
    position
})

export const positionFailure = error => ({
    type: POSITION_FAILURE,
    error
})

export const positionReset = () => ({
    type: POSITION_RESET
})

export const positionDeletedReset = () => ({
    type: POSITION_DELETE_RESET
})

export const positionUpdate = (idToken, id, update) => ({
    type: POSITION_UPDATE,
    idToken,
    id,
    update
})

export const positionUpdateSuccess = position => ({
    type: POSITION_UPDATE_SUCCESS,
    position
})

export const positionUpdateFailure = error => ({
    type: POSITION_UPDATE_FAILURE,
    error
})

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// ACTIONS FOR A NEW POSITION
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
export const positionNew = (idToken, newPosition) => ({
    type: POSITION_NEW,
    idToken,
    newPosition
})

export const positionNewSuccess = position => ({
    type: POSITION_NEW_SUCCESS,
    position
})

export const positionNewFailure = error => ({
    type: POSITION_NEW_FAILURE,
    error
})
