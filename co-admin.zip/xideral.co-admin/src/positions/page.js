import React, { PropTypes } from 'react'
import { Link } from 'react-router'

const PositionPage = ({children}) => (
    <section>
        <header className={"actions_page"}>
            <Link onlyActiveOnIndex activeClassName="active" to='/positions'>Listado</Link>
            <Link onlyActiveOnIndex activeClassName="active" to='/positions/new'>Nuevo</Link>
        </header>
        <div>{children}</div>
    </section>
)

PositionPage.propTypes = {
    children: PropTypes.node.isRequired
}

export default PositionPage