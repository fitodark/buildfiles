import _ from 'lodash'
import React, { PropTypes } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import functional from 'react-functional'

// local libraries
import { PositionAddForm } from './forms'
import Loader from '../shared-pages/loader'
import { positionReset, positionDeletedReset } from './reducer'
import { selectors as authSelectors } from '../auth'
import { getNewPosition, getNewPositionError, getNewPositionIsLoading } from './selectors'

const PositionNew = ({isLoading, error}) => (
  isLoading ? <Loader /> :
  <section>
    {error ? <div className="error">{error}</div> : null}
    <PositionAddForm />
  </section>
)

PositionNew.propTypes = {
  isLoading: PropTypes.bool.isRequired,
  error: PropTypes.object
}

PositionNew.componentWillUnmount = ({actions}) => {
  actions.positionReset()
  actions.positionDeletedReset()
}

const mapStateToProps = state => ({
  idToken: authSelectors.getIdToken(state),
  position: getNewPosition(state),
  isLoading: getNewPositionIsLoading(state),
  error: getNewPositionError(state)
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators ({
    positionReset,
    positionDeletedReset
  }, dispatch)
})


export default connect(mapStateToProps, mapDispatchToProps)(functional(PositionNew))