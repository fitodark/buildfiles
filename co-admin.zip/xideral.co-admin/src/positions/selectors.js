import _ from 'lodash'
import { createSelector } from 'reselect'

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// SELECTORS FOR POSITIONS
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
const getPositions = state => state.positions.positionList.positions

export const getPositionsError = state => state.positions.positionList.error

export const getPositionsIsLoading = state => state.positions.positionList.loading

export const getSortedPositions = createSelector(
    [getPositions],
    positions => _.orderBy(positions, ['published'], ['desc'])
)

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// SELECTORS FOR POSITION
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
export const getPosition = state => state.positions.activePosition.position 

export const getPositionEditable = state => state.positions.activePosition.editable

export const getPositionError = state => state.positions.activePosition.error

export const getPositionIsLoading = state => state.positions.activePosition.loading

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// SELECTORS FOR ADD A NEW POSITION
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 

export const getNewPosition = state => state.positions.newPosition.position 

export const getNewPositionError = state => state.positions.newPosition.error

export const getNewPositionIsLoading = state => state.positions.newPosition.loading