import React, { PropTypes } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import functional from 'react-functional'
import {
    Card,
    HeadingLink, 
    Text
} from 'rebass'
import uuid from 'uuid'
import { positionsFetch } from './reducer'
import {
    getSortedPositions,
    getPositionsError,
    getPositionsIsLoading
} from './selectors'
import { selectors as authSelectors } from '../auth'
import Loader from '../shared-pages/loader'
import {
    renderCardImage,
    renderDate,
    renderUntilFirstDot
} from '../libs/utils'

import { renderDetails } from './detail'

const PositionsList = ({ isLoading, positions, error }) => (
    isLoading ? <Loader /> :
    <section style={{ display: 'flex', flexFlow: 'row wrap' }}>
    <div className = "error" > { error ? error : null } </div> 
    {positions
        .map(data => (
            <Card key={uuid.v4()} m={2} style={{ width: '300px', height: '350px'}}>
                <HeadingLink level={3} href={`/positions/detail/${data.id}`} rel="noopener noreferrer">
                    {data.title}
                </HeadingLink>
                {renderDetails(data, false)}
            </Card>
        ))
    }
    </section>
)

PositionsList.propTypes = {
    positions: PropTypes.array.isRequired,
    isLoading: PropTypes.bool.isRequired,
    error: PropTypes.object
}

PositionsList.componentDidMount = ({
    idToken,
    actions
}) => actions.positionsFetch(idToken)

const mapStateToProps = state => ({
    idToken: authSelectors.getIdToken(state),
    positions: getSortedPositions(state),
    isLoading: getPositionsIsLoading(state),
    error: getPositionsError(state)
})

const mapDispatchToProps = dispatch => ({
    actions: bindActionCreators({
        positionsFetch
    }, dispatch)
})

export default connect(mapStateToProps, mapDispatchToProps)(functional(PositionsList))
