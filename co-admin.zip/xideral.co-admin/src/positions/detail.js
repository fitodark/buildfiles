import _ from 'lodash'
import React, { PropTypes } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import functional from 'react-functional'
import { Text } from 'rebass'
import uuid from 'uuid'

// local libraries
import { PositionUpdateForm } from './forms'
import Loader from '../shared-pages/loader'
import { positionFetch, positionReset, positionDeletedReset, positionEditable } from './reducer'
import { selectors as authSelectors } from '../auth'
import { getPosition, getPositionEditable, getPositionError, getPositionIsLoading } from './selectors'
import {renderCardImage, renderDate, renderUntilFirstDot} from '../libs/utils'
import '../assets/scss/page.scss'

export const renderDetails = (data, displaySkills=true) => (

<section className="details">
  <Text><span>Lugar:</span> {data.place}</Text>
  <Text><span>Ubicación especifica:</span> {data.area}</Text>
  <Text><span>Publicado:</span> {renderDate(data.published)}</Text>
  
  {displaySkills ? 
    <div className="skills">
      <Text><span>Habilidades:</span></Text>
      <ul>
        {data.skills ? data.skills.map(skill => (<li key={uuid.v4()}>{skill}</li>)) : 'loading...'}
      </ul>
  </div> : <Text><span>Habilidades:</span> {data.skills ? data.skills.length : 'loading...'}</Text>}    
  <Text><span>Detalles:</span></Text> <Text>{data.detail}</Text>
</section>
)

const PositionDetail = ({isLoading, position, editable, error, actions}) => (
  isLoading ? <Loader /> :
  <section>
    <h3>
        {position.title}
    </h3>
    {renderDetails(position)}

    <button className={"btn btn-yellow"} onClick={() => actions.positionEditable(position)}>Editar</button>
    {editable ? <PositionUpdateForm position={position} /> : null}
  </section>
)

PositionDetail.propTypes = {
  position: PropTypes.object.isRequired,
  isLoading: PropTypes.bool.isRequired,
  editable: PropTypes.bool.isRequired,
  error: PropTypes.object
}

PositionDetail.componentDidMount = ({idToken, id, actions}) => actions.positionFetch(idToken, id)

PositionDetail.componentWillUnmount = ({actions}) => {
  actions.positionReset()
  actions.positionDeletedReset()
}

const mapStateToProps = (state, ownProps) => ({
  idToken: authSelectors.getIdToken(state),
  id: ownProps.params.id,
  position: getPosition(state),
  editable: getPositionEditable(state),
  isLoading: getPositionIsLoading(state),
  error: getPositionError(state)
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators ({
    positionFetch,
    positionEditable,
    positionReset,
    positionDeletedReset
  }, dispatch)
})


export default connect(mapStateToProps, mapDispatchToProps)(functional(PositionDetail))
