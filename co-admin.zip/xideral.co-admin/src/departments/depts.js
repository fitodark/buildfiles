import React, { PropTypes } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import ImmutablePropTypes from 'react-immutable-proptypes'
import functional from 'react-functional'

import { deptsRequest } from './reducer'
import { getSortedDepts, getError, getIsFetching } from './selectors'
import { selectors as authSelectors } from '../auth'
import Loader from '../shared-pages/loader'
import {Tabs, Pane} from '../shared-components/tabs'

import DeptsList from './list'

const DeptoPage = ({ isFetching, depts, error }) => (
    isFetching ? <Loader /> :
    <section>
        <div className="error">{error ? error : null}</div>
         <Tabs title="Departments" selected={1}>
            <Pane label="">
                No Pane
            </Pane>
            <Pane label="Listado">
                <DeptsList depts={depts} />
            </Pane>
         </Tabs>
    </section>
)

DeptoPage.propTypes = {
    depts: ImmutablePropTypes.map.isRequired,
    isFetching: PropTypes.bool.isRequired,
    error: PropTypes.object
}

DeptoPage.componentDidMount = ({ idToken, actions }) => actions.deptsRequest(idToken)

const mapStateToProps = state => ({
    idToken: authSelectors.getIdToken(state),
    depts: getSortedDepts(state),
    isFetching: getIsFetching(state),
    error: getError(state)
})

const mapDispatchToProps = dispatch => ({
    actions: bindActionCreators({ deptsRequest }, dispatch)
})

export default connect(mapStateToProps, mapDispatchToProps)(functional(DeptoPage))