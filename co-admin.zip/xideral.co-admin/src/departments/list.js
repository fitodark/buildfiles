import React, { PropTypes } from 'react'
import ImmutablePropTypes from 'react-immutable-proptypes'
import functional from 'react-functional'
import { Card, HeadingLink, Text }  from 'rebass'

import Loader from '../shared-pages/loader'

const DeptsList = ({depts}) => (
    <section>
        {depts
            .entrySeq()
            .map(([id, dept]) => (
                    <Card key={id} m={2} style={{ width: '97%', height: '400px', border: '0' }}>
                        <HeadingLink level={2} rel="noopener noreferrer">
                            {dept.get('name')}
                        </HeadingLink>
                        <div className="gallery">
                            {dept
                                .get('members')
                                .map((m, index) => (
                                    <div key={index} className="profile">
                                    <img src={m.avatar} alt={m.name} className="avatar" />
                                    <Text small >{m.name}</Text>
                                    </div>
                                ))
                            }
                        </div>
                    </Card>
                )
             )
        }
    </section>
)

DeptsList.propTypes = {
    depts: ImmutablePropTypes.map.isRequired
}



export default functional(DeptsList)