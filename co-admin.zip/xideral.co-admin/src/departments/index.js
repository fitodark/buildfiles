import reducer, * as actions from './reducer'
import * as sagas from './sagas'
import * as selectors from './selectors'

import Dept from './model'

export { actions, reducer, sagas, selectors, Dept }