import { Map } from 'immutable'

export const DEPT_REQUEST = 'DEPT_REQUEST'
export const DEPT_SUCCESS = 'DEPT_SUCCESS'
export const DEPT_FAILURE = 'DEPT_FAILURE'
export const DEPT_DISPLAY_DROPZONE = 'DEPT_DISPLAY_DROPZONE'

export const initialState = new Map({
    isFetching: false,
    depts: new Map(),
    error: null
})

export default function reducer(state = initialState, action) {
    switch (action.type) {
        case DEPT_REQUEST:
            return state.set('isFetching', true)
        case DEPT_SUCCESS:
            return state.merge({
                isFetching: false,
                depts: action.depts,
                error: null
            })
        case DEPT_FAILURE:
            return state.merge({
                isFetching: false,
                error: action.error
            })
        default:
            return state
    }
}
/*
actions redux is our helper to call our reducer
 */
export const deptsRequest = idToken => ({
    type: DEPT_REQUEST,
    idToken
})

export const deptsSuccess = depts => ({
    type: DEPT_SUCCESS,
    depts
})

export const deptsFailure = error => ({
    type: DEPT_FAILURE,
    error
})