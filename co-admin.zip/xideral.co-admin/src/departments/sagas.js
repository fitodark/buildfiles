import 'isomorphic-fetch'
import { call, put, take } from 'redux-saga/effects'

import { 
    DEPT_REQUEST,
    deptsSuccess,
    deptsFailure 
} from './reducer'

import { fetchDepts, handleApiError } from '../api'

export function* fetchDeptsSaga(idToken) {
    try {
        const { depts } = yield call(fetchDepts, idToken)
        
        yield put(deptsSuccess(depts))
    } catch (error) {
        yield call(handleApiError, error, deptsFailure)
    }
}

export function* watchDeptsRequest() {
    while(true) {
        const { idToken } = yield take(DEPT_REQUEST)

        yield call(fetchDeptsSaga, idToken)
    }
}