import { createSelector } from 'reselect'

const getDepts = state => state.depts.get('depts')

export const getError = state => state.depts.get('error')

export const getIsFetching = state => state.depts.get('isFetching')

export const getSortedDepts = createSelector(
    [getDepts],
    depts => depts.sortBy(d => d.get('name'))
)