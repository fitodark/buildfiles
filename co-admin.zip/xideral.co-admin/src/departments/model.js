import { Record, Map } from 'immutable'

const Dept = new Record({
    _id: '',
    name: '',
    members: new Map(),
})

export default Dept