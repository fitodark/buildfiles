import React, {PropTypes} from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'

import { toggleDropdown } from './reducer'
import { getIsDropdownOpen } from './selectors'
import Header from '../shared-pages/header'
import LeftAside from '../shared-pages/aside'
import { actions as authActions, selectors as authSelectors } from '../auth'

const App = ({ children, isDropdownOpen, profile, actions }) => (
  <main>
    <Header 
      profile={profile}
      handleLogin={() => actions.loginRequest()}
      handleLogout={() => actions.logout()}
      onToggleDropdown={() => actions.toggleDropdown()}
      isDropdownOpen={isDropdownOpen}
    />
    <section className="container-fluid pane">
      {profile ? <LeftAside className="nav-pane" /> : null}
      <div className="content-pane container">{children}</div>
    </section>
  </main>
  )

App.propTypes = {
  children: PropTypes.node.isRequired,
  isDropdownOpen: PropTypes.bool.isRequired,
  profile: PropTypes.object,
  actions: PropTypes.object.isRequired
}

const mapStateToProps = state => ({
  isDropdownOpen: getIsDropdownOpen(state),
  profile: authSelectors.getProfile(state)
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators({ toggleDropdown, ...authActions }, dispatch)
})

export default connect(mapStateToProps, mapDispatchToProps)(App)