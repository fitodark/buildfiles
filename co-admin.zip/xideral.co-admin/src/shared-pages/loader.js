import React from 'react'

const Loader = () => (<div>Cargando...</div>)

Loader.propTypes = {
    // nothing for the moment
}

export default Loader