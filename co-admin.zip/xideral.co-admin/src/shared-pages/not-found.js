import React from 'react'
import functional from 'react-functional'

const NotFound = (props) => (<div>HOME PAGE.</div>)

export default functional(NotFound)