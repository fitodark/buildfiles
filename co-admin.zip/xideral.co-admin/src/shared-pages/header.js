import React, { PropTypes } from 'react'
import { Link, IndexLink } from 'react-router'
import { NavItem, Button, Dropdown, DropdownMenu, Arrow } from 'rebass'
import ImmutablePropTypes from 'react-immutable-proptypes'

// load assets
import '../assets/scss/header.scss'
import logoDesktop from '../assets/images/icons/logo-desktop.svg'
import logoMobile from '../assets/images/icons/logo-mobile.svg'

const Header = ({ profile, handleLogin, handleLogout, onToggleDropdown, isDropdownOpen }) => (
  <header className="main-header">
    <div className="header-logo hide-down-medium">
        <Link to='/'><img src={logoDesktop} alt="Xideral Admin"/></Link>
    </div>
    <div className="header-logo hide-up-medium">
        <Link to='/'><img src={logoMobile} alt="X"/></Link>
    </div>
    <div>
      <span>Admin V0.0.3</span>
      <NavItem is="object">
        {
          !profile ?
            <Button onClick={handleLogin} backgroundColor="#ffdd00">
              Login
            </Button> :
            <Dropdown>
              <NavItem color="midgray" onClick={() => onToggleDropdown()}>
                {profile.get('name')}
                <Arrow />
              </NavItem>
              <DropdownMenu
                right
                onDismiss={() => onToggleDropdown()}
                open={isDropdownOpen}
              >
                <NavItem onClick={() => handleLogout()} >
                  <img className={"avatar"} src={profile.get('picture')} />
                </NavItem>
                <NavItem onClick={() => handleLogout()}>
                  Logout
                </NavItem>
              </DropdownMenu>
            </Dropdown>
        }
      </NavItem>
    </div>
  </header>
)

Header.propTypes = {
  handleLogin: PropTypes.func.isRequired,
  handleLogout: PropTypes.func.isRequired,
  isDropdownOpen: PropTypes.bool.isRequired,
  onToggleDropdown: PropTypes.func.isRequired,
  profile: ImmutablePropTypes.map
}

export default Header