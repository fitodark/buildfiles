import React, { PropTypes } from 'react'
import { Link, IndexLink } from 'react-router'

import ImmutablePropTypes from 'react-immutable-proptypes'

// load assets
import '../assets/scss/aside.scss'

const LeftAside = (props) => (<aside className={props.className}>
        <nav className="main-nav">
          <ul>
            <li><Link to='/candidates' activeClassName='active' >Candidatos</Link></li>
            <li><Link to='/departments' activeClassName='active' >Departamentos</Link></li>
            <li><Link to='/news' activeClassName='active' >Noticias</Link></li>
            <li><Link to='/positions' activeClassName='active' >Posiciones</Link></li>
          </ul>
        </nav>
      </aside>)

export default LeftAside