import React from 'react'
import functional from 'react-functional'

const Home = (props) => (<div>HOME PAGE.</div>)

export default functional(Home)