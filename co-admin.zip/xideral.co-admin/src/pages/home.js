import React, {Component} from 'react'
import {Link} from 'react-router'
import {api} from '../libs/ajax'
import {moment, formats} from '../libs/utils'
import routes from '../routes'
// The home is our public area to display information about xideral at this point
// I love the idea to display the our news similar way like in the page
// and it will redirect to the news page at xideral.

// pages and assets
import '../assets/scss/theme.scss'
import Header from '../components/header'

const post = routes.post

class BlogList extends Component {
  constructor(props) {
    super(props)
    this.state = {
      posts: null
    }
    this.fetch = this.fetch.bind(this)
  }
  
  formatDate(date){
    const _date = moment(date).format('dddd, LL')
    return _date.charAt(0).toUpperCase() + _date.slice(1).toLowerCase()
  }

  fetch() {
    api
    .get(post.list).then(response => {
      this.setState({posts: response.data})
    })
    .catch(e => console.log('<BlogList> error', e))
  }

  componentDidMount(){
    this.fetch()
  }
  
  render() {
    console.log(this.state.posts)
    if (!this.state.posts) return null
    const {posts} = this.state
    const {title} = this.props

    return (
      <div className="container posts">
        <header>
          <h2>{title}</h2>
        </header>
        {posts.map(post => {
          return (
              <article className="post" key={post.id}>
                  <span>{this.formatDate.bind(this, post.published)()}</span>
                  <h3><Link to={`${this.props.url}/${post.id}`} target="_blank">{post.title}</Link></h3>
                  <p>{post.detail}</p>
              </article>
            )
        })}
      </div>
    )

  }
}

BlogList.defaultProps = {
  title: 'Últimas noticias',
  url: 'http://xideral.co/news'
}

class Home extends Component {
  
  render() {
    let children = null
    if (this.props.children) {
      children = React.cloneElement(this.props.children, {
        auth: this.props.route.auth // sends auth instance from route to children
      })
    }
    return (
      <section>
        <Header />
        <nav className="navigation">
          {children}
        </nav>
        <BlogList />
      </section>
    )
  }

}

export {Home}