// Third Party Libs
import React, {Component} from 'react'
import Formsy from 'formsy-react'
import _ from 'lodash'

// local libraries
import {axios, api} from '../libs/ajax'

import Input from '../components/input'
import Textarea from '../components/textarea'
import Table from '../components/table'

import {Tabs, Pane} from '../components/tabs'

import '../assets/scss/positions.scss'

class PositionForm extends Component {
  constructor(props) {
    super(props)
    this.state = {
      canSubmit: false
    }
    this.submit = this.submit.bind(this)
    this.enableButton = this.enableButton.bind(this)
    this.disableButton = this.disableButton.bind(this)
  }

  enableButton() {
    this.setState({ canSubmit: true })
  }
  disableButton() {
    this.setState({ canSubmit: false })
  }
  submit(data) {
    api.post('/admin/position', data)
    .then(response => {
      console.log(response.data)
      // this.disableButton()
    })
    .catch(e => console.log(e.data))
  }

  _buildForm() {
      /*
        "id" : 1,
        "area" : "Dessarrolladores",
        "title" : "Desarrollador/a Junior",
        "place" : "Monterrey",
        "detail" : "Buscamos a una persona con al menos 2 años de experiencia
            en desarrollo web y aplicaciones. Debe dominar Java y Weblogic,
            tener gusto por el diseño y creatividad para resolver problemas.",
        "skills" : [
            "UNIX",
            "JAVA SE, JAVA EE y JAVA ME",
            "Web services Soap and Rest",
            "SO Unix, Programación de shells",
            "Base de datos (MySQL, Oracle, SQL Server)"
        ],
        "published" : ISODate("2016-11-07T06:40:44.000Z"),
        "__v" : 0
       */
     return(
       <Formsy.Form
         onSubmit={this.submit}
         onValid={this.enableButton}
         onInvalid={this.disableButton}
         className="">
         {this.props.content ? <Input className="hide" type="text" name="_id"
             value={this.props.content} /> : null}


         <Input className="" type="text" name="area" label="Area" value=""
           autoComplete="off"
           placeholder="Desarrolladores, Project Managers ..."
           validations="minLength:3"
           validationError="Debe escribir el área a la cuál la vacante está asociada."
           required />

         <Input className="" type="text" name="title" label="Título" value=""
           autoComplete="off"
           placeholder="Desarrollador/a Junior"
           validations="minLength:3"
           validationError="Debe escribir el título de la vacante."
           required />

         <Input className="" type="text" name="place" label="Lugar" value=""
           autoComplete="off"
           placeholder="CD México, Monterrey"
           validations="minLength:3"
           validationError="Debe escribir el lugar de la vacante."
           required />

         <Input className="" type="text" name="skills" label="Hábilidades requeridas" value=""
            placeholder="UNIX; Java, Java EE; Javscript."
            validations="minLength:3"
            validationError="Debe escribir las hábilidades requeridas de la vacante."
            required />

         <Textarea
              className=""
              rows={3}
              cols={40}
              value=""
              name="detail"
              label="Detalle de la vacante"
              validations="minLength:40"
              validationError="Podrías explicar más sobre la vacante."
              required="isTrue"
            />

         <button type="submit" disabled={!this.state.canSubmit}
           className="btn">Aplicar</button>
       </Formsy.Form>
     )
  }
  render(){
    return (
      <section>
        {this._buildForm()}
      </section>
    )
  }
}


class ListPositions extends Component{
  constructor (props) {
    super(props)
    this.state = {
      positions: null
    }
  }
  componentDidMount(){
    api.get('/positions')
    .then(response => {
      this.setState({
        positions: response.data
      })
    })
    .catch(e => console.log("Admin <componentDidMount> retrieving Positions", e))

  }
  render () {
    if (! this.state.positions) return null
    const {positions} = this.state
    const _excludeItems = ['_id', '__v']
    const _fixedSize = ['detail']
    return (
      <Table content={positions} excludeItems={_excludeItems} fixedItems={_fixedSize}/>
    )
  }

}

class AdminPosition extends Component {
  render() {
    return (
      <section className="container-positions">
        <Tabs title="Posiciones" selected={0}>
          <Pane label="Todas">
            <ListPositions />
          </Pane>
          <Pane label="Agregar">
            <PositionForm />
          </Pane>
        </Tabs>

      </section>
    )
  }
}

export default AdminPosition
