import React, {Component} from 'react'

class Dashboard extends Component {
  render() {
    return (
      <section>
        <h3>Dashboard</h3>
      </section>
    )
  }
}

export default Dashboard
