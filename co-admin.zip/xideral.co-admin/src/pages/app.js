import React, {Component} from 'react'

// local components
import Header from '../components/header'
import LeftAside from '../components/left-aside'

// load sass theme
import '../assets/scss/theme.scss'


class App extends Component {
  render() {
    return (
      <div>
        <Header />
        <section className="container-fluid pane">
          <LeftAside className="nav-pane" />
          <div className="content-pane container">{this.props.children}</div>
          {/* Add footer */}
        </section>
      </div>
      )
  }
}

export default App
