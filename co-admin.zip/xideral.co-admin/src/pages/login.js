import React, {Component} from 'react'
import '../assets/scss/login.scss'
import AuthService from '../libs/auth'

class ButtonLogin extends Component {

}

class Login extends Component {
  render() {
    const { auth } = this.props
    console.log('Login', auth)
    return  (
      <div className={"login__inline"}>
          <button className="btn btn-yellow" onClick={auth.login.bind(this)}>Login</button>
      </div>
    )
    
    // <button className="btn btn-yellow" onClick={auth.login.bind(this)}>Acceder</button>
    
    
    /*(
      <section className={"login-container"}>
         <header>
          <h3>Xideral Admin</h3> 
          <small>Version 0.0.1</small>
        </header>
        <div className={"login"}>  
          <label htmlFor="user">Usuario</label>
          <input type="text" name="user" placeholder="usuario" />
          <label htmlFor="password">Password</label>
          <input type="password" name="password" placeholder="*******" />
        </div>
      </section>
    )*/
  }
}

Login.propTypes = {
  location: React.PropTypes.object,
  auth: React.PropTypes.instanceOf(AuthService)
}
export default Login
