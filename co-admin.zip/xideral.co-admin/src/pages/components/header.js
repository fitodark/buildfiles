import React, {Component} from 'react'
import {Link} from 'react-router'
// load assets
import '../assets/scss/header.scss'
import logoDesktop from '../assets/images/icons/logo-desktop.svg'
import logoMobile from '../assets/images/icons/logo-mobile.svg'

class Header extends Component {
  render() {
    return (
      <header className="main-header">
        <div className="header-logo hide-down-medium">
            <Link to='/admin'><img src={logoDesktop} alt="Xideral Admin"/></Link>
        </div>
        <div className="header-logo hide-up-medium">
            <Link to='/admin'><img src={logoMobile} alt="X"/></Link>
        </div>
        <div>
          <span>Admin Version 0.0.1a</span>
        </div>

      </header>
    )
  }
}

export default Header
