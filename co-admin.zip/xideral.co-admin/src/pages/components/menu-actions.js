import React, {Component} from 'react'
import {Link} from 'react-router'


class MenuActions extends Component {
  render() {
    const { title, allLink, addLink, updateLink } = this.props
    return (
      <header className="menu-actions">
        <h3>Posiciones</h3>
        <nav>
          <ul>
            <li key={1}><Link activeClassName="active">Todas</Link></li>
            <li key={2}><Link activeClassName="active">Agregar</Link></li>
            <li key={3}><Link activeClassName="active">Modificar</Link></li>
          </ul>
        </nav>
      </header>
    )
  }
}

export default MenuActions
