import React, {Component} from 'react'
import {Link} from 'react-router'

// load assets
require('../assets/scss/aside.scss')

class LeftAside extends Component {
  render() {
    const {className} = this.props
    return (
      <aside className={className}>
        <nav className="main-nav">
          <ul>
            <li><Link to='/admin/positions' activeClassName='active' >Posiciones</Link></li>
            <li><Link to='/admin/news' activeClassName='active' >Noticias</Link></li>
            <li><Link to='/admin/departments' activeClassName='active' >Departamentos</Link></li>
          </ul>
        </nav>
      </aside>
    )
  }
}

export default LeftAside
