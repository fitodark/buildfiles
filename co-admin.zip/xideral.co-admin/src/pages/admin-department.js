// Third Party Libs
import React, {Component} from 'react'
import Formsy from 'formsy-react'
import _ from 'lodash'

// local libraries
import {axios, api} from '../libs/ajax'

import Input from '../components/input'
import Textarea from '../components/textarea'
import Table from '../components/table'

import {Tabs, Pane} from '../components/tabs'

import '../assets/scss/positions.scss'



class DepartmentForm extends Component {
  constructor(props) {
    super(props)
    this.state = {
      canSubmit: false
    }
    this.submit = this.submit.bind(this)
    this.enableButton = this.enableButton.bind(this)
    this.disableButton = this.disableButton.bind(this)
  }

  enableButton() {
    this.setState({ canSubmit: true })
  }
  disableButton() {
    this.setState({ canSubmit: false })
  }
  submit(data) {
    api.post('/admin/department', data)
    .then(response => {
      console.log(response.data)
      // this.disableButton()
    })
    .catch(e => console.log(e.data))
  }

  _buildFormArea() {
     return(
       <Formsy.Form
         onSubmit={this.submit}
         onValid={this.enableButton}
         onInvalid={this.disableButton}
         className="">
         {this.props.content ? <Input className="hide" type="text" name="_id"
             value={this.props.content} /> : null}


         <Input className="" type="text" name="area" label="Area" value=""
           autoComplete="off"
           placeholder="Desarrolladores, Project Managers ..."
           validations="minLength:3"
           validationError="Debe escribir el área a la cuál la vacante está asociada."
           required />

         <Input className="" type="text" name="area" label="Area" value=""
           autoComplete="off"
           placeholder="Desarrolladores, Project Managers ..."
           validations="minLength:3"
           validationError="Debe escribir el área a la cuál la vacante está asociada."
           required />


         <button type="submit" disabled={!this.state.canSubmit}
           className="btn">Next</button>
       </Formsy.Form>
     )
  }
  render(){
    return (
      <section>
        {this._buildForm()}
      </section>
    )
  }
}


class ListDepartments extends Component{
  constructor (props) {
    super(props)
    this.state = {
      departments: null
    }
  }
  componentDidMount(){
    api.get('/departments')
    .then(response => {
      this.setState({
        departments: response.data
      })
    })
    .catch(e => console.log("Admin <componentDidMount> retrieving Positions", e))

  }
  render () {
    if (! this.state.departments) return null
    const {departments} = this.state
    const _excludeItems = ['_id', '__v']
    const _fixedSize = []
    return (
      <Table content={departments} excludeItems={_excludeItems} fixedItems={_fixedSize}/>
    )
  }

}

class AdminDepartment extends Component {
  render() {
    return (
      <section className="container-positions">
        <Tabs title="Departamentos" selected={0}>
          <Pane label="Todas">
            <ListDepartments />
          </Pane>
          <Pane label="Agregar">
            <DepartmentForm />
          </Pane>
        </Tabs>

      </section>
    )
  }
}

class AdminDepartmentDetail extends Component {
  render() {
    return (
      <section className="container-positions">
        Department detail

      </section>
    )
  }
}

export {AdminDepartment, AdminDepartmentDetail}
