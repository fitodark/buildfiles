import React, {Component} from 'react'

class Tabs extends Component{
  constructor(props) {
    super(props)
    this.state = {
      selected: this.props.selected
    }
  }
  handleClick(index, event) {
    event.preventDefault()
    this.setState({
      selected: index
    })
  }
  _renderContent () {
    return (
      <section>
        {this.props.children[this.state.selected]}
      </section>
    )
  }
  _renderNavigation () {
    const labels = (child, index) => {
      const activeClass = this.state.selected === index ? 'active' : ''
      return (
        <li key={index}>
          <a href="#"
             className={activeClass}
             onClick={this.handleClick.bind(this, index)}>
             {child.props.label}
          </a>
        </li>
      )
    }
    return (
      <nav className="tabs__actions">
        <ul>
          {this.props.children.map(labels.bind(this))}
        </ul>
      </nav>
    )
  }
  render() {
    return (
      <section>
        <div className="tabs__header">
          <h3>{this.props.title || ""}</h3>
          {this._renderNavigation()}
        </div>
        <div className="tabs__content">
            {this._renderContent()}
        </div>
      </section>
    )
  }
}

Tabs.defaultProps = {
  selected: 0
}

Tabs.propTypes = {
  title: React.PropTypes.string,
  selected: React.PropTypes.number,
  children: React.PropTypes.oneOfType([
    React.PropTypes.array,
    React.PropTypes.element
  ]).isRequired
}


class Pane extends Component {
  render() {
    return (
      <div>{this.props.children}</div>
    )
  }
}



export {Tabs, Pane}
