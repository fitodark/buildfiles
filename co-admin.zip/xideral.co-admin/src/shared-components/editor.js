/**
 * At this point we remove the support for embed since we cannot display
 * on our front-end, when I learn more about draft-js we could add this feature
 */
// Third Party Libraries
import React from 'react';
import ReactDOM from 'react-dom';

// local libraries
import {axios, api} from '../libs/ajax'

// styles
import '../assets/scss/page.scss';
import 'medium-draft/lib/index.css';
import {convertFromRaw, convertToRaw,
        KeyBindingUtil, Modifier, AtomicBlockUtils, Entity} from 'draft-js'
import {
  ImageSideButton,
  Block,
  addNewBlock, addNewBlockAt,
  beforeInput,
  createEditorState,
  rendererFn,
  Editor,
  StringToTypeMap,
  HANDLED,
  NOT_HANDLED
} from 'medium-draft';

const newTypeMap = StringToTypeMap;
newTypeMap['2.'] = Block.OL;

const { hasCommandModifier } = KeyBindingUtil;

/*
Convert quotes to curly quotes.
*/
const DQUOTE_START = '“';
const DQUOTE_END = '”';
const SQUOTE_START = '‘';
const SQUOTE_END = '’';

const handleBeforeInput = (editorState, str, onChange) => {
  if (str === '"' || str === '\'') {
    const currentBlock = getCurrentBlock(editorState);
    const selectionState = editorState.getSelection();
    const contentState = editorState.getCurrentContent();
    const text = currentBlock.getText();
    const len = text.length;
    if (selectionState.getAnchorOffset() === 0) {
      onChange(EditorState.push(editorState, Modifier.insertText(contentState, selectionState, (str === '"' ? DQUOTE_START : SQUOTE_START)), 'transpose-characters'));
      return HANDLED;
    } else if (len > 0) {
      const lastChar = text[len - 1];
      if (lastChar !== ' ') {
        onChange(EditorState.push(editorState, Modifier.insertText(contentState, selectionState, (str === '"' ? DQUOTE_END : SQUOTE_END)), 'transpose-characters'));
      } else {
        onChange(EditorState.push(editorState, Modifier.insertText(contentState, selectionState, (str === '"' ? DQUOTE_START : SQUOTE_START)), 'transpose-characters'));
      }
      return HANDLED;
    }
  }
  return beforeInput(editorState, str, onChange, newTypeMap);
};

class SeparatorSideButton extends React.Component {
  constructor(props) {
    super(props);
    this.onClick = this.onClick.bind(this);
  }

  onClick() {
    const entityKey = Entity.create('separator', 'IMMUTABLE', {});
    this.props.setEditorState(
      AtomicBlockUtils.insertAtomicBlock(
        this.props.getEditorState(),
        entityKey,
        '-'
      )
    );
    this.props.close();
  }

  render() {
    return (
      <button
        className="md-sb-button md-sb-img-button"
        type="button"
        title="Agregar separador"
        onClick={this.onClick} >
        <i className="fa fa-minus" />
      </button>
    );
  }
}

class EmbedSideButton extends React.Component {

  static propTypes = {
    setEditorState: React.PropTypes.func,
    getEditorState: React.PropTypes.func,
    close: React.PropTypes.func,
  };

  constructor(props) {
    super(props);
    this.onClick = this.onClick.bind(this);
    this.addEmbedURL = this.addEmbedURL.bind(this);
  }

  onClick() {
    const url = window.prompt('Enter a URL', 'https://www.youtube.com/watch?v=PMNFaAUs2mo');
    this.props.close();
    if (!url) {
      return;
    }
    this.addEmbedURL(url);
  }

  addEmbedURL(url) {
    const entityKey = Entity.create('embed', 'IMMUTABLE', {url});
    this.props.setEditorState(
      AtomicBlockUtils.insertAtomicBlock(
        this.props.getEditorState(),
        entityKey,
        'E'
      )
    );
  }

  render() {
    return (
      <button
        className="md-sb-button md-sb-img-button"
        type="button"
        title="Agrega un Embed (video youtube, comentario twitter)"
        onClick={this.onClick}
      >
        <i className="fa fa-code" />
      </button>
    );
  }

}

class AtomicEmbedComponent extends React.Component {

  static propTypes = {
    data: React.PropTypes.object.isRequired,
  }

  constructor(props) {
    super(props)

    this.state = {
      showIframe: false,
    };

    this.enablePreview = this.enablePreview.bind(this)
  }

  componentDidMount() {
    this.renderEmbedly()
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState.showIframe !== this.state.showIframe && this.state.showIframe === true) {
      this.renderEmbedly()
    }
  }

  getScript() {
    const script = document.createElement('script')
    script.async = 1;
    script.src = '//cdn.embedly.com/widgets/platform.js'
    script.onload = () => {
      window.embedly()
    }
    document.body.appendChild(script)
  }

  renderEmbedly() {
    if (window.embedly) {
      window.embedly()
    } else {
      this.getScript()
    }
  }

  enablePreview() {
    this.setState({
      showIframe: true,
    })
  }

  render() {
    const { url } = this.props.data;
    const innerHTML = `<div><a class="embedly-card" href="${url}" data-card-key="9aca2c07f8004bd3b5b7469f7aec7505" data-card-controls="0" data-card-theme="dark">Embedded ― ${url}</a></div>`;
    return (
      <div className="md-block-atomic-embed">
        <div dangerouslySetInnerHTML={{ __html: innerHTML }} />
      </div>
    );
  }
}

const AtomicSeparatorComponent = (props) => (
  <hr />
);

const AtomicBlock = (props) => {
  const { blockProps, block } = props;
  const entity = Entity.get(block.getEntityAt(0));
  const data = entity.getData();
  const type = entity.getType();
  if (blockProps.components[type]) {
    const AtComponent = blockProps.components[type];
    return (
      <div className={`md-block-atomic-wrapper md-block-atomic-wrapper-${type}`}>
        <AtComponent data={data} />
      </div>
    );
  }
  return <p>Block of type <b>{type}</b> is not supported.</p>;
};

class S3ImageSideButton extends ImageSideButton {

  onChange(e) {
    const file = e.target.files[0];
    if (file.type.indexOf('image/') === 0) {
      api
      .get(`/getSignedUrl?folder=news&filename=${file.name}&filetype=${file.type}`)
      .then(response => {
        const signedUrl = response.data.url
        const options = {
          headers: {
            'Content-Type': file.type
          }
        }
        // put to aws
        return axios.put(signedUrl, file, options)
      })
      .then(response => {
        // second step save the data to our database
       this.props.setEditorState(addNewBlock(
         this.props.getEditorState(),
         Block.IMAGE, {
           src: response.request.responseURL.split("?")[0]
         }
       ));

      })
      .catch(e => console.log('Error Uploading in blog', e))
    }
    this.props.close();
  }
}

class MyEditor extends React.Component {
  constructor(props) {
    super(props);

    this.sideButtons = [
      {
      title: 'Image',
      component: S3ImageSideButton,
      },
      // {
      //   title: 'Embed',
      //   component: EmbedSideButton,
      // },
      // {
      //   title: 'Separator',
      //   component: SeparatorSideButton,
      // }
    ];

    const data = this.props.content || null;

    this.state = {
      editorState: createEditorState(data) // for empty content
    };

    this.onChange = (editorState) => {
      this.setState({ editorState });
    };
    this.handleDroppedFiles = this.handleDroppedFiles.bind(this)
  }

  componentDidMount() {
    this.refs.editor.focus();
  }

  rendererFn(setEditorState, getEditorState) {
    const atomicRenderers = {
      embed: AtomicEmbedComponent,
      separator: AtomicSeparatorComponent,
    };
    const rFnOld = rendererFn(setEditorState, getEditorState);
    const rFnNew = (contentBlock) => {
      const type = contentBlock.getType();
      switch(type) {
        case Block.ATOMIC:
          return {
            component: AtomicBlock,
            editable: false,
            props: {
              components: atomicRenderers,
            },
          };
        default: return rFnOld(contentBlock);
      }
    };
    return rFnNew;
  }

  handleDroppedFiles(selection, files) {
    const file = files[0];
    if (file.type.indexOf('image/') === 0) {
      api
      .get(`/getSignedUrl?folder=news&filename=${file.name}&filetype=${file.type}`)
      .then(response => {
        const signedUrl = response.data.url
        const options = {
          headers: {
            'Content-Type': file.type
          }
        }
        // put to aws
        return axios.put(signedUrl, file, options)
      })
      .then(response => {
      // second step save the data to our database
         this.onChange(addNewBlockAt(
           this.state.editorState,
           selection.getAnchorKey(),
           Block.IMAGE, {
             src: response.request.responseURL.split("?")[0]
           }
         ))
      })
      .catch(e => console.log('Error Uploading in blog', e))
      return true;
    }
    return false
  }


  render() {
    const { editorState } = this.state;
    return (
      <Editor
        ref="editor"
        editorState={editorState}
        onChange={this.onChange}
        handleDroppedFiles={this.handleDroppedFiles}

        placeholder={this.props.placeholder}
        beforeInput={handleBeforeInput}
        sideButtons={this.sideButtons}
        rendererFn={this.rendererFn}
      />
    );
  }
};
export default MyEditor;
