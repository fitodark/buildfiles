import React, {Component} from 'react'
import {moment, formats, toUpper, inArray} from '../libs/utils'


class Column extends Component {
  _buildHeader(keys, exclude, fixed){
    return keys.filter(k => !inArray(k, exclude)).map((key, index) => {
      const value = toUpper(key)
      const className = inArray(key, fixed) ? 'table__fixed--width' : ''
      return <th className={className} key={index}>{value}</th>
    })
  }
  _buildBody(keys, content, exclude) {
    return keys.filter(k => !inArray(k, exclude)).map((key, index) => {
      const isDate = moment(content[key], formats, true).isValid()
      const value = isDate ? moment(content[key]).format("lll") : content[key]
      return <td key={index}>{value}</td>
    })
  }
  render () {
    const {content, excludeColumns, fixedColumns} = this.props
    const keys = this.props.isHead ? content : _.keys(content)
    return (
      <tr>
        {this.props.isHead ?
          this._buildHeader.bind(this, keys, excludeColumns, fixedColumns)() :
          this._buildBody.bind(this, keys, content, excludeColumns)()}
      </tr>
    )
  }
}

const Table = ({content, keys, className, excludeItems, fixedItems}) => (
    <table className={className || "table"}>
      <thead>
          <Column excludeColumns={excludeItems}
            fixedColumns={fixedItems} isHead={true} content={keys} />
      </thead>

      <tbody>
        {content.map((pos, index) => {
          return (
            <Column excludeColumns={excludeItems} key={index} content={pos} />
          )
        })}
      </tbody>
    </table>
)


export default Table
