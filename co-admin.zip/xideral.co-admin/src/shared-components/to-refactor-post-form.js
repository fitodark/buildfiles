import React, {Component} from 'react'
import {browserHistory} from 'react-router'
import Dropzone from 'react-dropzone';
import Formsy from 'formsy-react'
import {
  convertFromRaw,
  convertToRaw,
  EditorState,
} from 'draft-js';

// local libraries
import { selectors as authSelectors } from '../auth'

import {axios, api} from '../libs/ajax'

import Input from './input'
import Textarea from './textarea'

import MyEditor from './editor'
import routes from './endpoints'

const post = routes['post']

class PostForm extends Component {
  constructor(props) {
    super(props)

    this.state = {
      data: props.content,
      canSubmit: false,
      files: [],
      rejFiles: [],
      isDropZoneVisible: false
    }

    this.submit = this.submit.bind(this)
    this.displayDropZone = isDropZoneVisible => {this.setState({isDropZoneVisible})
    this.onDrop = (files, rejFiles) =>  this.setState({files, rejFiles});
    }
  }
  _dropZone(){
    // this method is called to display or hide the Dropzone
    return (<div className="drop">
      <Dropzone onDrop={this.onDrop}
        className='drop-zone'
        maxSize={2.097e6}
        accept="image/jpeg,image/png,image/gif">
        <label>Carga la Imagén (jpg, png, gif) dando click o simplemente Arrastrala.</label>
      </Dropzone>
      <div id='dropzone-message'>
        {this.state.files.length > 0 ?
          <div>
            <span style={{marginTop: 10 + "px"}}>   {this.state.files[0].name}</span>
            <div>{this.state.files.map((file, index) => <img key={index} src={file.preview} /> )}</div>
          </div> : null}

        {this.state.rejFiles.length > 0 ? <div>
          <span style={{marginTop: 10 + "px"}}>
            {this.state.rejFiles[0].name}, No es un archivo válido.
          </span>
        </div> : null}
      </div>
    </div>)
  }
  _addMainPost(data) {
    const file = this.state.files[0]
    api
    .get(`/getSignedUrl?folder=news&filename=${file.name}&filetype=${file.type}`)
    .then(response => {
      const signedUrl = response.data.url
      const options = {
        headers: {
          'Content-Type': file.type
        }
      }
      return axios.put(signedUrl, file, options)
    })
    .then(function (response) {
      // second step save the data to our database
      data['image'] = response.request.responseURL.split("?")[0]
       // adding owner
      data['owner'] = JSON.parse(localStorage.getItem('profile')).name

      return api.post(post.add, data)
    }).then(response => {
      browserHistory.push("/news/detail/" + response.data.id)
    })
    .catch(e => console.log('error adding nothing',e))
  }
  _addPost(data) {
     // adding owner
    data['owner'] = JSON.parse(localStorage.getItem('profile')).name

    api.post(post.add, data)
    .then(response => {
      browserHistory.push("/news/detail/" + response.data.id)
    }).catch(e => console.log('oops!!!', e))
  }
  _updateMainPost(data, id) {
    const file = this.state.files[0]
    api
    .get(`/getSignedUrl?folder=news&filename=${file.name}&filetype=${file.type}`)
    .then(response => {
      const signedUrl = response.data.url
      const options = {
        headers: {
          'Content-Type': file.type
        }
      }
      return axios.put(signedUrl, file, options)
    })
    .then(function (response) {
      // second step save the data to our database
      data['image'] = response.request.responseURL.split("?")[0]
       // adding owner
      data['owner'] = JSON.parse(localStorage.getItem('profile')).name

      return api.put(post.edit.replace(':id', id), data)
    }).then(response => {
      console.log('saved', response.data)
      // send a message of saved
      this.setState({data: response.data})

    })
    .catch(e => console.log(e))
  }
  _updatePost(data, id) {
    // adding owner
    data['owner'] = JSON.parse(localStorage.getItem('profile')).name

    api.put(post.edit.replace(':id', id), data)
    .then(response => {
      // send a message of saved
      this.setState({data: response.data})
      browserHistory.push("/news/detail/" + response.data.id)
    }).catch(e => console.log(e))
  }
  submit(data) {
    //console.log(convertToRaw(this.refs.xEditor.state.editorState.getCurrentContent()))
    data['content'] = JSON.stringify(convertToRaw(this.refs.xEditor.state.editorState.getCurrentContent()))
    if (this.state.data._id) { // check if the post was submited previous tu update it.
      const id = this.state.data.id
      data.isMain && this.state.files.length > 0 ?
          this._updateMainPost.bind(this, data, id)() : this._updatePost.bind(this, data, id)()
    } else {
      data.isMain && this.state.files.length > 0 ?
          this._addMainPost.bind(this, data)() : this._addPost.bind(this, data)()
    }
  }
  dropNew(id) {

    api.delete(post.drop.replace(':id', id))
    .then(response => {
      // redirect weee need to solve it before to reload
      console.log('removed send message')

    }).catch(e => console.log(e))

    browserHistory.push(post.list)

  }
  _buildForm() {
    const {data} = this.state
    return(<Formsy.Form onSubmit={this.submit} className="">

      <Input className="input-vertical" type="text" name="title" label="Título."
        value={data.title}
        autoComplete="off" validations="minLength:3"
        validationError="Debe escribir un título para la noticia."
        placeholder={"JS es asombroso, descubre más..."}
        required />

      <Textarea className="input-vertical" name='detail' label="Detalle."
        value={data.detail}
        placeholder={this.props.detailPlaceholder}
        required />

      <Input className="input-inline" type="checkbox" name="isMain" label="¿Está noticia es la principal?."
            value={data.isMain}
            onChangeChecked={this.displayDropZone} />
      {this.state.isDropZoneVisible ? this._dropZone.bind(this)() : null }

      <MyEditor ref='xEditor' content={JSON.parse(data.content)}
        placeholder={this.props.contentPlaceholder} />


      {this.props.displayDelete && data.id ?
      <button onClick={this.dropNew.bind(this, data.id)} className="btn btn-delete">Borrar</button>  : null }
      <button type="submit" className="btn btn-yellow">Guardar</button>
    </Formsy.Form>)
  }
  render() {
    return this._buildForm.bind(this)()
  }
}

PostForm.defaultProps = {
  content: {
    title: "",
    detail: "",
    isMain: false,
    image: "",
    content: null
  }
}
export default PostForm
