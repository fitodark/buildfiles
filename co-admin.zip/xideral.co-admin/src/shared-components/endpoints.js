const routes =  {
  post: {
    add:  '/new',
    edit: '/new/:id',
    drop: '/new/delete/:id',
    list: '/news'
  }
}
module.exports = routes