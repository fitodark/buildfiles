import { fork } from 'redux-saga/effects'

import { sagas as authSagas } from './auth'
import { sagas as postsSagas } from './news'
import { sagas as positionsSagas } from './positions'
import { sagas as deptsSagas } from './departments'
import { sagas as candidatesSaga } from './candidates'

export default function* rootSaga() {
  yield [
    fork(authSagas.watchLoginRequest),
    fork(authSagas.watchLoginSuccess),
    fork(authSagas.watchLoginFailure),
    fork(authSagas.watchLogout),

    fork(deptsSagas.watchDeptsRequest),
    
    fork(candidatesSaga.watchCandidatesRequest),  // for get list
    fork(candidatesSaga.watchCandidateRequest),   // for get detail
    fork(candidatesSaga.watchCandidateUpdate),    // for update a record
    fork(candidatesSaga.watchCandidateSave),      // for new record

    fork(postsSagas.watchPostsRequest),  // for get list
    fork(postsSagas.watchPostRequest),   // for get detail
    fork(postsSagas.watchPostUpdate),    // for update a record
    fork(postsSagas.watchPostSave),      // for new record

    fork(positionsSagas.watchPositionsRequest),  // for get list
    fork(positionsSagas.watchPositionRequest),   // for get detail
    fork(positionsSagas.watchPositionUpdate),    // for update a record
    fork(positionsSagas.watchPositionSave),      // for new record

  ]
}