import 'isomorphic-fetch'
import { put } from 'redux-saga/effects'
import { Map } from 'immutable'

import { actions as authActions } from './auth'
import { Dept } from './departments'
import { Post } from './news'

export const API_URI = process.env.NODE_ENV !== 'production' ? 'http://localhost:5000/api/v1' : 'http://xideral.co:5000/api/v1'

const getFetchInit = (idToken, requestMethod, body) => {
  const requestHeaders = new Headers()
  requestHeaders.append('Authorization', `Bearer ${idToken}`)
  requestHeaders.append('Content-Type', 'application/json')

  const fetchInit = { method: requestMethod, headers: requestHeaders }

  if (body) {
    fetchInit.body = JSON.stringify(body)
  }
  return fetchInit
}

/**
 * CANDIDATES API
 */

// fetch all
export async function fetchCandidates(idToken) {
  const response = await fetch(`${API_URI}/candidates`, getFetchInit(idToken, 'GET'))
  const candidates = await response.json().then(json => json)
  try {
    return { candidates: candidates }
  } catch (err) {
    throw new Error(`Error ocurred downstream: ${err}`)
  }
}

// fetch candidate
export async function fetchCandidate(idToken, id) {
  const response = await fetch(`${API_URI}/candidates/${id}`, getFetchInit(idToken, 'GET'))
  const candidate = await response.json().then(json => json)
  try {
    return { candidate: candidate[0] }
  } catch (err) {
    throw new Error(`Error ocurred downstream: ${err}`)
  }
}

export async function updateCandidate(idToken, id, update) {
  const response = await fetch(`${API_URI}/candidate/${id}`, getFetchInit(idToken, 'PUT', update))
  const candidate = await response.json().then(json => json)
  try {
    return { candidate: candidate }
  } catch (err) {
    throw new Error(`Error ocurred downstream: ${err}`)
  }
}

// save a new candidate
export async function saveCandidate(idToken, newCandidate) {
  const response = await fetch(`${API_URI}/candidate`, getFetchInit(idToken, 'POST', newCandidate))
  const candidate = await response.json().then(json => json)
  try {
    return { candidate: candidate}
  } catch (err) {
    throw new Error(`Error ocurred downstream: ${err}`)
  }
}

// delete candidate  TODO in next release


/**
 * DEPTS API
 */
const mapDeptsToKeyValuePair = data => [data, new Dept(data)]

export async function fetchDepts(idToken) {
  const response = await fetch(`${API_URI}/departments`, getFetchInit(idToken, 'GET'))
  const depts = await response.json().then(json => json)
  try {
    return { depts: new Map(depts.map(mapDeptsToKeyValuePair))}
  } catch (err) {
    throw new Error(`Error ocurred downstream: ${err}`)
  }
}

/**
 * NEWS API
 */
// fetch all
export async function fetchPosts(idToken) {
  const response = await fetch(`${API_URI}/news`, getFetchInit(idToken, 'GET'))
  const posts = await response.json().then(json => json)
  try {
    return { posts: posts }
  } catch (err) {
    throw new Error(`Error ocurred downstream: ${err}`)
  }
}


// fetch post
export async function fetchPost(idToken, id) {
  console.warn('REFACTOR ENDPOINT from new/:id to news/:id to keep the same nomenclature.')
  const response = await fetch(`${API_URI}/new/${id}`, getFetchInit(idToken, 'GET'))
  const post = await response.json().then(json => json)
  console.log('fetchPost', post)
  try {
    return { post: post }
  } catch (err) {
    throw new Error(`Error ocurred downstream: ${err}`)
  }
}

// update post
export async function updatePost(idToken, id, update) {
  const response = await fetch(`${API_URI}/new/${id}`, getFetchInit(idToken, 'PUT', update))
  const post = await response.json().then(json => json)
  try {
    return { post: post }
  } catch (err) {
    throw new Error(`Error ocurred downstream: ${err}`)
  }
}

// save a new post
export async function savePost(idToken, newPosition) {
  const response = await fetch(`${API_URI}/new`, getFetchInit(idToken, 'POST', newPosition))
  const post = await response.json().then(json => json)
  try {
    return { post }
  } catch (err) {
    throw new Error(`Error ocurred downstream: ${err}`)
  }
}

/**
 * POSITIONS API
 */

// fetch all
export async function fetchPositions(idToken) {
  const response = await fetch(`${API_URI}/positions`, getFetchInit(idToken, 'GET'))
  const positions = await response.json().then(json => json)
  try {
    return { positions: positions }
  } catch (err) {
    throw new Error(`Error ocurred downstream: ${err}`)
  }
}

// fetch position
export async function fetchPosition(idToken, id) {
   console.log('fetchPosition ===')
  const response = await fetch(`${API_URI}/positions/${id}`, getFetchInit(idToken, 'GET'))
  const position = await response.json().then(json => json)
  console.log('fetchPosition', position)
  try {
    return { position: position }
  } catch (err) {
    throw new Error(`Error ocurred downstream: ${err}`)
  }
}

export async function updatePosition(idToken, id, update) {
  const response = await fetch(`${API_URI}/position/${id}`, getFetchInit(idToken, 'PUT', update))
  const position = await response.json().then(json => json)
  try {
    return { position: position }
  } catch (err) {
    throw new Error(`Error ocurred downstream: ${err}`)
  }
}

// save a new position
export async function savePosition(idToken, newPosition) {
  const response = await fetch(`${API_URI}/position`, getFetchInit(idToken, 'POST', newPosition))
  const position = await response.json().then(json => json)
  try {
    return { position: position}
  } catch (err) {
    throw new Error(`Error ocurred downstream: ${err}`)
  }
}

// delete position TODO in next release


export function* handleApiError(error, failureAction) {
  const response = error.response

  if (response === undefined) {
    yield put(failureAction(error.message))
  } else if (response.status === 401) {
    yield put(authActions.loginRequest())
  } else {
    const responseError = {
      status: response.status,
      statusText: response.statusText,
      message: error.message
    }
    yield put(failureAction(responseError))
  }
}
