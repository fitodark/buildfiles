import _ from 'lodash'
import React, { PropTypes } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import functional from 'react-functional'

// local libraries
// import { PostAddForm } from './forms'
import PostForm from '../shared-components/to-refactor-post-form'
import Loader from '../shared-pages/loader'
import { postReset, postDeletedReset } from './reducer'
import { selectors as authSelectors } from '../auth'
import { getNewPost, getNewPostError, getNewPostIsLoading } from './selectors'

const PostNew = ({isLoading, error}) => (
  isLoading ? <Loader /> :
  <section className="blog-pane">
    {error ? <div className="error">{error}</div> : null}
    <PostForm
      detailPlaceholder={"El texto descrito aquí se mostrará en el listado de las noticias."}
      contentPlaceholder={"El texto descrito aquí será el contenido de la noticia"}
    />
  </section>
)

PostNew.propTypes = {
  isLoading: PropTypes.bool.isRequired,
  error: PropTypes.object
}

PostNew.componentWillUnmount = ({actions}) => {
  actions.postReset()
  actions.postDeletedReset()
}

const mapStateToProps = state => ({
  idToken: authSelectors.getIdToken(state),
  post: getNewPost(state),
  isLoading: getNewPostIsLoading(state),
  error: getNewPostError(state)
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators ({
    postReset,
    postDeletedReset
  }, dispatch)
})


export default connect(mapStateToProps, mapDispatchToProps)(functional(PostNew))