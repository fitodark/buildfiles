import _ from 'lodash'
import React, { PropTypes } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import functional from 'react-functional'
import { Text } from 'rebass'
import { browserHistory } from 'react-router'
// local libraries
import { PostUpdateForm } from './forms'
import Loader from '../shared-pages/loader'
import { postFetch, postReset, postDeletedReset, postEditable } from './reducer'
import { selectors as authSelectors } from '../auth'
import { getPost, getPostEditable, getPostError, getPostIsLoading } from './selectors'
import {
    renderCardImage,
    renderDate,
    renderUntilFirstDot
} from '../libs/utils'
import Preview from '../shared-components/preview'

const PostDetail = ({isLoading, post, editable, error, actions}) => (
  isLoading ? <Loader /> :
  <section className="blog-pane">
    
    {post.image ? renderCardImage(post.image) : null}
    <Text small style={{textAlign: 'right'}}>
      {post.published ? renderDate(post.published) : 'loading...'}
    </Text>
    <h3>
        {post.title}
    </h3>
    <Text>{post.detail ? renderUntilFirstDot(post.detail) : 'loading...'}</Text>
    <Text small style={{textAlign: 'right'}}>Creado por: {post.owner}</Text>
    {console.log('post content', post.content)}
    {post.content ? <Preview content={JSON.parse(post.content)} /> : 'loading...'}
    <button onClick={() => browserHistory.push(`/news/edit/${post.id}`)}>Editar</button>
    {/* <button onClick={() => actions.postEditable(post)}>Editar</button>
    {editable ? <PostUpdateForm post={post} /> : null} */}
  </section>
)

PostDetail.propTypes = {
  post: PropTypes.object.isRequired,
  isLoading: PropTypes.bool.isRequired,
  editable: PropTypes.bool.isRequired,
  error: PropTypes.object
}

PostDetail.componentDidMount = ({idToken, id, actions}) => {
  return actions.postFetch(idToken, id)
}
PostDetail.componentWillUnmount = ({actions}) => {
  actions.postReset()
  actions.postDeletedReset()
}

const mapStateToProps = (state, ownProps) => ({
  idToken: authSelectors.getIdToken(state),
  id: ownProps.params.id,
  post: getPost(state),
  editable: getPostEditable(state),
  isLoading: getPostIsLoading(state),
  error: getPostError(state)
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators ({
    postFetch,
    postEditable,
    postReset,
    postDeletedReset
  }, dispatch)
})


export default connect(mapStateToProps, mapDispatchToProps)(functional(PostDetail))
