import React, { PropTypes } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import functional from 'react-functional'
import uuid from 'uuid'
import {
    Card,
    HeadingLink,
    Text
} from 'rebass'

import { postsFetch } from './reducer'
import {
    getSortedPosts,
    getPostsError,
    getPostsIsLoading
} from './selectors'
import { selectors as authSelectors } from '../auth'
import Loader from '../shared-pages/loader'
import {
    renderCardImage,
    renderDate,
    renderUntilFirstDot
} from '../libs/utils'

import { renderLinkedInPost, renderPost } from './detail'

const PostsList = ({ isLoading, posts, error }) => (
    isLoading ? <Loader /> :
    <section style={{ display: 'flex', flexFlow: 'row wrap' }}>
    <div className = "error" > { error ? error : null } </div> 
    {posts
        .map(post => (
            <Card key={uuid.v4()} m={2} 
                  style={{ width: '280px', height: '360px',
                         borderRight: '1px solid rgba(0, 0, 0, 0.05)',
                         boxShadow: '0 3px 3px 0 rgba(0, 0, 0, 0.05)'}}>
                {post.image ? renderCardImage(post.image) : null}
                <Text small style={{textAlign: 'right'}}>{renderDate(post.published)}</Text>
                <HeadingLink level={2} href={`/news/detail/${post.id}`} rel="noopener noreferrer">
                    {post.title}
                </HeadingLink>
                <Text>{renderUntilFirstDot(post.detail)}</Text>
                <Text small style={{textAlign: 'right'}}>Creado por: {post.owner}</Text>
            </Card>
        ))
    }
    </section>
)

PostsList.propTypes = {
    posts: PropTypes.array.isRequired,
    isLoading: PropTypes.bool.isRequired,
    error: PropTypes.object
}

PostsList.componentDidMount = ({
    idToken,
    actions
}) => actions.postsFetch(idToken)

const mapStateToProps = state => ({
    idToken: authSelectors.getIdToken(state),
    posts: getSortedPosts(state),
    isLoading: getPostsIsLoading(state),
    error: getPostsError(state)
})

const mapDispatchToProps = dispatch => ({
    actions: bindActionCreators({
        postsFetch
    }, dispatch)
})

export default connect(mapStateToProps, mapDispatchToProps)(functional(PostsList))
