import React, { PropTypes } from 'react'
import { Link } from 'react-router'

const PostPage = ({children}) => (
    <section>
        <header className={"actions_page"}>
            <Link onlyActiveOnIndex activeClassName="active" to='/news'>Listado</Link>
            <Link onlyActiveOnIndex activeClassName="active" to='/news/new'>Nuevo</Link>
        </header>
        <div>{children}</div>
    </section>
)

PostPage.propTypes = {
    children: PropTypes.node.isRequired
}

export default PostPage