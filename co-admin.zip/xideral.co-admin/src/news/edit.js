import _ from 'lodash'
import React, {Component} from 'react'

// local libraries
import {axios, api} from '../libs/ajax'

import PostForm from '../shared-components/to-refactor-post-form'

import routes from '../shared-components/endpoints'

const post = routes.post

class PostEdit extends Component {
  constructor(props) {
    super(props)
    this.state = {
      content: null
    }
  }
  componentDidMount() {
    const id = +this.props.params.id
    console.log('PostEdit Component', post.edit.replace(":id", id))
    api.get(post.edit.replace(":id", id))
    .then(response => {
      this.setState({
        content: response.data
      })
    })
    .catch(e => console.log(`Retrieving the new with id: ${id}`, e))

  }
  componentWillReceiveProps(nextProps) {
    const id = +nextProps.id
    api.get(post.edit.replace(":id", id))
    .then(response => {
      this.setState({
        content: response.data
      })
    })
    .catch(e => console.log(`Retrieving the new with id: ${id}`, e))

  }
  render(){
    if (_.isEmpty(this.state.content)) {
      return (
        <div>
          <h1>OOPS!</h1>
          <p>No encontramos el post {this.props.params.id} </p>
        </div>
      )
    } else {
      return (
        <section>

            <header>
              <h3>Editar Noticia</h3>
            </header>

            <PostForm content={this.state.content}
              detailPlaceholder={"El texto descrito aquí se mostrará en el \
                                   listado de las noticias."}
              contentPlaceholder={"El texto descrito aquí será el contenido \
                                   de la noticia"}
              displayDelete={true}
            />

        </section>
      )
    }
  }
}


export default PostEdit
