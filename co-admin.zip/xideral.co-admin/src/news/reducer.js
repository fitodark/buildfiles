// List
export const POSTS_FETCH = 'POSTS_FETCH'
export const POSTS_SUCCESS = 'POSTS_SUCCESS'
export const POSTS_FAILURE = 'POSTS_FAILURE'
export const POSTS_RESET = 'POSTS_RESET'

export const POST_FETCH = 'POST_FETCH'
export const POST_SUCCESS = 'POST_SUCCESS'
export const POST_FAILURE = 'POST_FAILURE'
export const POST_EDITABLE = 'POST_EDITABLE'
export const POST_NON_EDITABLE = 'POST_NON_EDITABLE'
export const POST_RESET = 'POST_RESET'

export const POST_UPDATE = 'POST_UPDATE'
export const POST_UPDATE_SUCCESS = 'POST_UPDATE_SUCCESS'
export const POST_UPDATE_FAILURE = 'POST_UPDATE_FAILURE'

export const POST_DELETE_RESET = 'POST_DELETE_RESET'

export const POST_NEW = 'POST_NEW'
export const POST_NEW_SUCCESS = 'POST_NEW_SUCCESS'
export const POST_NEW_FAILURE = 'POST_NEW_FAILURE'

export const initialState = {
    postList: {
        posts: [],
        loading: false,
        error: null,
    },
    newPost: {
        post: {},
        loading: false,
        error: null,
    },
    activePost: {
        post: {},
        loading: false,
        editable: false,
        isUpdating: false,
        error: null,
    },
    deletePost: {
        post: {},
        loading: false,
        error: null,
    }
}

export default function reducer(state = initialState, action) {
    switch (action.type) {
        // posts
        case POSTS_FETCH:
            return { ...state, 
                    postList: 
                        {posts: [], error: null, loading: true}}
        case POSTS_SUCCESS:
            return { ...state, 
                    postList: 
                        {posts: action.posts, error: null, loading: false}}
        case POSTS_FAILURE:
            return { ...state, 
                    postList: 
                        {posts: [], error: action.error, loading: false}}
        case POSTS_RESET:
            return { ...state, 
                    postList: 
                        {posts: [], error: null, loading: false}}
        // end posts
        // post
        case POST_FETCH:
            return { ...state, activePost: {...state.activePost, loading: true}}
        case POST_SUCCESS:
            return { ...state, activePost: {post: action.post, editable: false, error: null, isUpdating: false, loading: false}}
        case POST_EDITABLE:
            return { ...state, activePost: {post: action.post, editable: true, error: null, isUpdating: false, loading: false}}
        case POST_NON_EDITABLE:
            return { ...state, activePost: {post: action.post, editable: false, error: null, isUpdating: false, loading: false}}
        case POST_FAILURE:
            return { ...state, activePost: {post: {}, error: action.error, editable: false, isUpdating: false, loading: false}}
        case POST_RESET:
            return { ...state, activePost: {post: {}, error: null, editable: false, isUpdating: false, loading: false}}
        case POST_UPDATE:
            return { ...state, activePost: {post: {}, error: null, editable: true, isUpdating: true, loading: false}}
        case POST_UPDATE_SUCCESS:
            return { ...state, activePost: {post: action.post, error: null, editable: true, isUpdating: false, loading: false}}
        case POST_UPDATE_FAILURE:
            return { ...state, activePost: {post: {}, error: action.error, editable: true, isUpdating: false, loading: false}}
        // end posts
        default:
            return state
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// ACTIONS FOR POSTS
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
export const postsFetch = idToken => ({
    type: POSTS_FETCH,
    idToken
})

export const postsSuccess = posts => ({
    type: POSTS_SUCCESS,
    posts
})

export const postsFailure = error => ({
    type: POSTS_FAILURE,
    error
})

export const postsReset = () => ({
    type: POSTS_RESET
})

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// ACTIONS FOR POST
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
export const postFetch = (idToken, id) => ({
    type: POST_FETCH,
    idToken,
    id
})

export const postSuccess = post => ({
    type: POST_SUCCESS,
    post
})

export const postEditable = post => ({
    type: POST_EDITABLE,
    post
})

export const postCancelEdition = post => ({
    type: POST_NON_EDITABLE,
    post
})

export const postFailure = error => ({
    type: POST_FAILURE,
    error
})

export const postReset = () => ({
    type: POST_RESET
})

export const postDeletedReset = () => ({
    type: POST_DELETE_RESET
})

export const postUpdate = (idToken, id, update) => ({
    type: POST_UPDATE,
    idToken,
    id,
    update
})

export const postUpdateSuccess = post => ({
    type: POST_UPDATE_SUCCESS,
    post
})

export const postUpdateFailure = error => ({
    type: POST_UPDATE_FAILURE,
    error
})

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// ACTIONS FOR A NEW POST
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
export const postNew = (idToken, newPost) => ({
    type: POST_NEW,
    idToken,
    newPost
})

export const postNewSuccess = post => ({
    type: POST_NEW_SUCCESS,
    post
})

export const postNewFailure = error => ({
    type: POST_NEW_FAILURE,
    error
})
