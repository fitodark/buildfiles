import 'isomorphic-fetch'
import _ from 'lodash'
import React from 'react'
import { Field, Form, reduxForm } from 'redux-form'
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import uuid from 'uuid'
import Dropzone from 'react-dropzone'
import { browserHistory } from 'react-router'

// local components
import { selectors as authSelectors } from '../auth'
import { postUpdate, postNew, postCancelEdition } from './reducer'
import { getPost } from './selectors'
import {API_URI} from '../api'
import MyEditor from '../shared-components/editor'
import Editor from 'medium-draft'
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FORM COMMONS
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const FIELDS = {
  title: {
    node: 'input',
    type: 'text',
    label: 'Título'
  },
  detail: {
    node: 'textarea',
    type: 'textarea',
    label: 'Detalle'
  },
  isMain: {
    node: 'input',
    type: 'checkbox',
    label: 'Principal?'
  },
  image: {
    node: 'input',
    type: 'file',
    label: 'Agrega imagen (solo si es nota principal)'
  },
  content: {
    node: 'input',
    type: 'editor',
    label: ''
  }
}

const DraftEditor = (field) => (<Editor editorState={field.value} onChange={field.onChange} /> )

const renderCaseComponent = (fieldConfig, field) => {
  switch (fieldConfig.type){
    case 'file':
      return <Field name={field} component={renderDropzone} />
    case 'editor':
      return <Field name={field} component={DraftEditor} />
    default:
      return <Field name={field} component={fieldConfig.node} type={fieldConfig.type} />
  }
}

const renderInput = (fieldConfig, field) => (
  <div key={`field_${field}`} className={field.touched && field.invalid ? 'danger' : ''}>
    <label htmlFor={field}>{fieldConfig.label}</label><br />

    {renderCaseComponent(fieldConfig, field)}

    <div className="text-help">
      {field.touched ? field.error : ''}
    </div>
  </div>
)

async function uploadToS3(files) {
  const file = files[0]
  const response = await fetch(`${API_URI}/getSignedUrl?folder=news&filename=${file.name}&filetype=${file.type}`, {
    method: 'GET'
  })
  const signedUrl = await response.json().then(json => json.url)
  const s3File = await fetch(signedUrl, {
    method: 'PUT',
    headers: {
      'Content-Type': file.type
    },
    body: file
  })
  file['image'] = s3File.url.split("?")[0]
  return [file]
}

function validate(values) {
  const errors = {}
  _.each(FIELDS, (type, field) => {
    if (!values[field]) {
      errors[field] = `Debe llenar el campo ${field}`
    }
  })
  return errors
}

const renderDropzone = (field) => {
  const files = field.input.value;
  return (
    <div>
      <Dropzone
        name={field.name}
        maxSize={2.097e6}
        accept="image/jpeg,image/png,image/gif"
        multiple={false}
        onDrop={( filesToUpload, e ) => uploadToS3(filesToUpload).then(files => field.input.onChange(files))}
        >
        <div>Arrastra la imagen principal</div>
      </Dropzone>
      <div></div>
      {field.meta.touched &&
        field.meta.error &&
        <span className="error">{field.meta.error}</span>}
      {files && Array.isArray(files) && (
        <ul>
          { files.map((file, i) => <li key={i}>{file.name}</li>) }
        </ul>
      )}
    </div>
  );
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FORM FOR POST UPDATE
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

const updatePost = (values, idToken, id, dispatch) => {
  if (Array.isArray(values['image'])) {
    values['image'] = values['image'][0].value // removing the file context to save only the url
  }
  dispatch(idToken, id, values)
}

const PostUpdateForm = ({idToken, handleSubmit, post, actions}) => (
<section style={{border: "1px solid grey", marginTop: '15px', padding: '10px'}}>
  <nav style={{ display: 'flex', justifyContent: 'flex-end'}}>
    <span style={{ cursor: 'pointer', fontSize: '18px', fontWeight: 'bolder'}}
          onClick={() => actions.postCancelEdition(post)}>X</span>
  </nav>
  <Form onSubmit={handleSubmit((data) => updatePost(data, idToken, post._id, actions.postUpdate))} className={"form-column"}>
    {_.map(FIELDS, (fieldConfig, field) => (
      renderInput(fieldConfig, field)
    ))}
    <button type="submit" className={`btn btn-default`}>Guardar</button>
  </Form>
</section>)

const mapStateToProps = state => ({
  idToken: authSelectors.getIdToken(state),
  initialValues: getPost(state)
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators({
    postCancelEdition,
    postUpdate,
  }, dispatch)
})

const UpdateForm = connect(mapStateToProps, mapDispatchToProps)(reduxForm({
  form: 'PostUpdateForm',
  fields: _.keys(FIELDS),
  validate
})(PostUpdateForm))

export { UpdateForm as PostUpdateForm }



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FORM FOR POST NEW
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


const addPost = (values, idToken, dispatch) => {
  // if (Array.isArray(values['image'])) {
  //   values['image'] = values['image'][0].value // removing the file context to save only the url
  // }
  // dispatch(idToken, values)
  console.log('Adding Post with values', values)
}

const mapStateToPropsAdd = state => ({
  idToken: authSelectors.getIdToken(state)
})

const mapDispatchToPropsAdd = dispatch => ({
  actions: bindActionCreators({
    postCancelEdition,
    postNew,
  }, dispatch)
})

const PostAddForm = ({idToken, handleSubmit, actions}) => (
<section style={{border: "1px solid grey", marginTop: '15px', padding: '10px'}}>
  <nav style={{ display: 'flex', justifyContent: 'flex-end'}}>
    <span style={{ cursor: 'pointer', fontSize: '18px', fontWeight: 'bolder'}}
          onClick={() => browserHistory.push('/news')}>X</span>
  </nav>
  <Form onSubmit={handleSubmit((data) => addPost(data, idToken, actions.postNew))} className={"form-column"}>
    {_.map(FIELDS, (fieldConfig, field) => (
      renderInput(fieldConfig, field)
    ))}
    <button type="submit" className={`btn btn-default`}>Guardar</button>
  </Form>
</section>)

const AddForm = connect(mapStateToPropsAdd, mapDispatchToPropsAdd)(reduxForm({
  form: 'PostAddForm',
  fields: _.keys(FIELDS),
  validate
})(PostAddForm))

export { AddForm as PostAddForm }
