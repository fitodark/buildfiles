import 'isomorphic-fetch'
import { call, put, take } from 'redux-saga/effects'

import { 
    POSTS_FETCH,
    POST_FETCH,
    POST_UPDATE,
    POST_NEW,
    postsSuccess,
    postsFailure,
    postSuccess,
    postFailure,
    postUpdateSuccess,
    postUpdateFailure,
    postNewSuccess,
    postNewFailure
} from './reducer'

import { fetchPosts, fetchPost, updatePost, savePost, handleApiError } from '../api'

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// SAGAS FOR POSTS
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
export function* fetchPostsSaga(idToken) {
    try {
        const { posts } = yield call(fetchPosts, idToken)
        
        yield put(postsSuccess(posts))
    } catch (error) {
        yield call(handleApiError, error, postsFailure)
    }
}

export function* fetchPostSaga(idToken, id) {
    try {
        const { post } = yield call(fetchPost, idToken, id)
        yield put(postSuccess(post))
    } catch (error) {
        yield call(handleApiError, error, postFailure)
    }
}

export function* fetchPostUpdateSaga(idToken, id, update) {
    try {
        const { post } = yield call(updatePost, idToken, id, update)
        yield put(postUpdateSuccess(post))
    } catch (error) {
        yield call(handleApiError, error, postUpdateFailure)
    }
}

export function* savePostSaga(idToken, newPost) {
    try {
        const { post } = yield call(savePost, idToken, newPost)
        yield put(postNewSuccess(post))
    } catch (error) {
        yield call(handleApiError, error, postNewFailure)
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
// DAEMONS FOR POSTS
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
export function* watchPostsRequest() {
    while(true) {
        const { idToken } = yield take(POSTS_FETCH)
        yield call(fetchPostsSaga, idToken)
    }
}

export function* watchPostRequest() {
    while(true) {
        const { idToken, id } = yield take(POST_FETCH)
        yield call(fetchPostSaga, idToken, id)
    }
}

export function* watchPostUpdate() {
    while(true) {
        const { idToken, id, update } = yield take(POST_UPDATE)
        yield call(fetchPostUpdateSaga, idToken, id, update)
    }
}

export function* watchPostSave() {
    while(true) {
        const { idToken, newPost } = yield take(POST_NEW)
        yield call(savePostSaga, idToken, newPost)
    }
}