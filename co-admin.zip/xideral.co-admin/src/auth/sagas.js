import Auth0Lock from 'auth0-lock'
import 'isomorphic-fetch'
import { call, put, take } from 'redux-saga/effects'
import { push } from 'react-router-redux'
import Immutable from 'immutable'
// local components and assets
import {
    LOGIN_REQUEST,
    LOGIN_SUCCESS,
    LOGIN_FAILURE,
    LOGOUT,
    loginFailure,
    loginSuccess
} from './reducer'
import { setStoredAuthState, removeStoredAuthState } from '../libs/utils'
import logo from '../assets/images/icons/logo-mobile.svg'

export function* loginRequest() {
    const client = process.env.CLIENT_AUTH0
    const domain = process.env.DOMAIN_AUTH0
    const lock = new Auth0Lock(client, domain, {
        languageDictionary: { title: "Xideral Company" },
        language: 'es',
        theme: {
            logo: logo,
            primaryColor: "#151d27"
        },
        auth: { redirect: false },
        allowSignUp: false,
        allowForgotPassword: false
    })

    const showLock = () => new Promise((resolve, reject) => {
        lock.on('hide', () => reject('Lock closed'));

        lock.on('authenticated', (authResult) => {
            lock.getUserInfo(authResult.accessToken, (error, profile) => {
                if (!error) {
                    lock.hide()
                    resolve({ profile: Immutable.fromJS(profile), idToken: authResult.accessToken })
                }
            })
        })

        lock.on('unrecoverable_error', (error) => {
            lock.hide()
            reject(error)
        })

        lock.show()
    })

    try {
        const {profile, idToken} = yield call(showLock)

        yield put(loginSuccess(profile, idToken))
        yield put(push('/dashboard'))
    } catch (error) {
        yield put(loginFailure(error))
        yield put(push('/'))
    }
}

export function* watchLoginRequest() {
    while (true) {
        yield take(LOGIN_REQUEST)
        yield call(loginRequest)
    }
}

export function* watchLoginSuccess() {
    while (true) {
        const { profile, idToken } = yield take(LOGIN_SUCCESS)
        setStoredAuthState(profile, idToken)
    }
}

export function* watchLoginFailure() {
    yield take(LOGIN_FAILURE)
    removeStoredAuthState()
}

export function* watchLogout() {
    while (true) {
        yield take(LOGOUT)
        removeStoredAuthState()
        yield put(push('/'))
    }
}
