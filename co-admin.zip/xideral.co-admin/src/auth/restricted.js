import React, { PropTypes } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import functional from 'react-functional'

// local components
import Loader from '../shared-pages/loader'
import { loginRequest } from './reducer'
import { getIdToken } from './selectors'

const Restricted = ({ children, idToken }) => (idToken ? children : <Loader />)

Restricted.propTypes = {
  children: PropTypes.node.isRequired,
  idToken: PropTypes.string
}

Restricted.componentWillMount = ({ actions, idToken }) => {
  if (!idToken) {
    actions.loginRequest()
  }
}

const mapStateToProps = state => ({
  idToken: getIdToken(state)
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators({ loginRequest }, dispatch)
})

export default connect(mapStateToProps, mapDispatchToProps)(functional(Restricted))