var webpack = require('webpack')
var DashboardPlugin = require('webpack-dashboard/plugin')
var ProvidePlugin = require('webpack/lib/ProvidePlugin');
var CommonsChunkPlugin = require("webpack/lib/optimize/CommonsChunkPlugin")
var path = require('path')
var loaders = require('./webpack.loaders')
var HtmlWebpackPlugin = require('html-webpack-plugin')
var CopyWebpackPlugin = require('copy-webpack-plugin');
var pkg = require('./package.json')
var BUILD_DIR = path.resolve(__dirname, 'dist')
var APP_DIR = path.resolve(__dirname, 'src')

function excludeOfVendors(name, vendors) {
  return vendors.indexOf(name) === -1
}
var _toExclude = ['babel-core', 'webpack']

var config = {
  context: __dirname,
  entry: {
    app: ['react-hot-loader/patch', APP_DIR + '/index.js'],
    vendors: Object.keys(pkg.dependencies)
                   .filter(name => excludeOfVendors(name, _toExclude))
  },
  resolve: { alias: {} },
  plugins: [
    new DashboardPlugin({}),
		new webpack.NoErrorsPlugin(),
		new webpack.HotModuleReplacementPlugin(),
    new webpack.optimize.UglifyJsPlugin({
      compress: {
          warnings: false
      }
    }),
    new CopyWebpackPlugin([{ from: APP_DIR + '/assets/sass', to: 'assets' }]),
    new CommonsChunkPlugin('vendors', 'vendors.min.js'),
		new HtmlWebpackPlugin({
      title: "Admin Xideral Website",
      inject: false,
			template: APP_DIR + '/app.html',
		}),
    new webpack.DefinePlugin({
    'process.env': {
      'NODE_ENV': JSON.stringify('production')
      },
    })
	],
  output: {
    path: BUILD_DIR,
    filename: '[name].min.js',
    publicPath: '/'
  },
  module: {
    noParse: [],
    loaders
  }
};

module.exports = config;
