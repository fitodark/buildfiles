echo "Terminando PIDS"
for pid in $(ps -fu $USER | grep admin | grep -v grep | awk '{ print $2 }'); do
  kill -9 $pid
done
# start app with
# CLIENT_AUTH0=BC5a3xSMdS06O8EeJkCp2mZRfRvKxAAz DOMAIN_AUTH0=paridin.auth0.com NODE_ENV=production yarn run dev &
